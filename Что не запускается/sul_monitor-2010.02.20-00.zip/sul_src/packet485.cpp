#include "stdafx.h"
#include <windows.h>
#include <iostream>
#include <string>
#include <istream>
#include <fstream>
#include <iomanip>

#ifndef PACKET485_H
#include "packet485.h"
#endif

using namespace std;

///////////////////////////////////////////////////////////////////////////////

packet485::packet485(device *dev)
{
	p.length = 0;
	p.paddr = NULL;
	hw = dev;
}

///////////////////////////////////////////////////////////////////////////////

packet485::~packet485()
{
	free_packet485();
}

///////////////////////////////////////////////////////////////////////////////

unsigned char packet485::data_crc()
{
	unsigned char dcrc = 0;
	struct dbg_header *h = (struct dbg_header *)p.paddr;

	if(h->size == 0)
		return 0;

	unsigned char *data_addr = (unsigned char *)(p.paddr + sizeof(struct dbg_header));

	for(unsigned i=0; i < (unsigned)h->size; i++)
	{
		dcrc += data_addr[i];
	}

	return dcrc;
}

///////////////////////////////////////////////////////////////////////////////

unsigned char packet485::header_crc()
{
	unsigned char hcrc = 0;
	unsigned char *ptr = p.paddr;

	for(unsigned i=0; i<sizeof(struct dbg_header)-1; i++)
	{
		hcrc += ptr[i];
	}

	return hcrc;
}

///////////////////////////////////////////////////////////////////////////////

unsigned char packet485::main_crc()
{
	unsigned char mcrc = 0;
	unsigned char *ptr = p.paddr;

	for(unsigned i=0; i<sizeof(struct main_packet)-1; i++)
	{
		mcrc += ptr[i];
	}

	return mcrc;
}

///////////////////////////////////////////////////////////////////////////////

unsigned char packet485::cmd_to_size( unsigned char cmd, unsigned char user_size )
{
	unsigned char size = 0;

	switch (cmd) {
		case host_eeprom_data: { size = 128; } break;
		case host_ram_data: { size = 128; } break;
		case target_eeprom_clear: { size = 1; } break;
		case target_ram_clear: { size = 1; } break;
		case target_eeprom_to_plm: { size = 0; } break;
		case target_ram_to_plm: { size = 0; } break;
		case target_eeprom_data: { size = 128; } break;
		case target_ram_data: { size = 128; } break;
		case target_eeprom_crc: { size = 2; } break;
		case target_ram_crc: { size = 2; } break;
                case target_ctrl_impulse: { size = 0; } break;
                case target_impulse_return: { size = 128; } break;
		case target_ctrl_channel: { size = 0; } break;
		case target_channel_return: { size = 128; } break;
		case target_ctrl_calc: { size = 0; } break;
		case target_calc_return: { size = 128; } break;
		//case host_to_target: { size = user_size; } break;
		//case target_to_host: { size = user_size; } break;
		case host_to_target: { size = 128; } break;
		case target_to_host: { size = 128; } break;
		case target_address: { size = 1; } break;        
	}

	return size;
}

///////////////////////////////////////////////////////////////////////////////

trans_type packet485::cmd_to_type( unsigned char cmd )
{
	trans_type type = unknown;

	switch (cmd) {
		case host_to_target:            
		case host_eeprom_data:
		case host_ram_data:
			type = to_target;
			break;
		case target_eeprom_data:
		case target_ram_data:
		case target_eeprom_crc:
		case target_ram_crc:
                case target_impulse_return:
		case target_channel_return:
		case target_calc_return:
		case target_to_host:
		case target_address:
			type = to_host;
			break;
                case target_eeprom_to_plm:
                case target_ram_to_plm:
                case target_eeprom_clear:
                case target_ram_clear:
                case target_ctrl_impulse:
                case target_ctrl_channel:
                case target_ctrl_calc:
                case target_reset:
                        type = to_target_cmd;
                        break;

	}

	return type;
}

///////////////////////////////////////////////////////////////////////////////

void packet485::create_packet485( unsigned char addr,
								 unsigned char cmd,
								 unsigned char bn,
								 void *data,
								 unsigned char data_size )
{
	free_packet485();

	//�������� ������ ������ ������
	p.length = sizeof(struct dbg_header) + data_size;

	//������� ����� ���� ������
	p.paddr = (unsigned char*)malloc(p.length);
	if(!p.paddr) {
		p.length = 0;
	}
	memset(p.paddr, 0, p.length);

	struct dbg_header *h = (struct dbg_header *)p.paddr;

	//��������� ���� ������ ������������ � ����� �����
	if(data)
		memcpy(p.paddr + sizeof(struct dbg_header), data, data_size);

	//�������� ��������� ���� ������ ������
	h->sign = signature;
	h->addr = addr;
	h->code = cmd;
	h->size = data_size;

	//����������� ����� ������ ������
	h->dcrc = data_crc();

	h->bnum = bn;
        h->txrx = cmd_to_type( h->code );

	//����������� ����� ��������� ������
	h->hcrc = header_crc();
}

///////////////////////////////////////////////////////////////////////////////

void packet485::create_packet485( unsigned short x, unsigned short y,
								 unsigned char cmd )
{
	free_packet485();

	//�������� ������ ������ ������
	p.length = sizeof(struct main_packet);

	//������� ����� ���� ������
	p.paddr = (unsigned char*)malloc(p.length);
	if(!p.paddr) {
		p.length = 0;
	}
	memset(p.paddr,0,p.length);

	struct main_packet *mpacket = (struct main_packet *)p.paddr;

	//�������� ��������� ���� ������ ������
	mpacket->mhdr.sign = signature;
	unsigned char x0 = (x & 0xff);
	unsigned char x1 = ((x >> 8) & 0xff);
	mpacket->mdata.x = x1 | (x0 << 8);
	unsigned char y0 = (y & 0xff);
	unsigned char y1 = ((y >> 8) & 0xff);
	mpacket->mdata.y = y1 | (y0 << 8);
	mpacket->mdata.cmd = cmd;

	//����������� ����� ������
	mpacket->mtail.mcrc = main_crc();
}

///////////////////////////////////////////////////////////////////////////////

void packet485::free_packet485( )
{
	// ��������� ��������� ������
	if(p.paddr) {
		free(p.paddr);
		p.length = 0;
		p.paddr = NULL;
	}
}

///////////////////////////////////////////////////////////////////////////////

int packet485::send_main_packet( )
{
	if(!hw) return -1;

	unsigned res = hw->write_data(p.paddr,p.length);
	if(res != p.length)
		return -1;

	return 0;
}

///////////////////////////////////////////////////////////////////////////////

int packet485::send_dbg_packet()
{
	if(!hw) return -1;

	struct dbg_header* hdr = (struct dbg_header*)p.paddr;

	if(!hdr) return -1;                

	// �������� ��������� ���������
	int res1 = hw->write_data(p.paddr,sizeof(dbg_header));
	if(res1 != sizeof(dbg_header))
		return -1;
	Sleep(5);

	// �������� ������
	int res2 = hw->write_data(p.paddr+sizeof(dbg_header),hdr->size);
	if(res2 != hdr->size)
		return -1;

	return res2;
}

///////////////////////////////////////////////////////////////////////////////

int packet485::receive_dbg_packet(void *buffer)
{
	if(!hw) return -1;

	if(!buffer) return -1;        

	struct dbg_header* hdr = (struct dbg_header*)p.paddr;

	if(!hdr) return -1;

	// �������� ��������� ���������
	int res1 = hw->write_data(p.paddr,sizeof(struct dbg_header));
	if(res1 != sizeof(dbg_header))
		return -1;
	Sleep(5);
	// ��������� ������
	int res2 = hw->read_data(buffer,hdr->size);
	if(res2 != hdr->size)
		return -1;

	return res2;
}

///////////////////////////////////////////////////////////////////////////////

int packet485::request( unsigned char addr,
					   unsigned char cmd,
					   unsigned char bn,
					   void *data,
					   unsigned char data_size )
{
	unsigned char res = 0;

	create_packet485( addr, cmd, bn, data, data_size );

	trans_type type = cmd_to_type(cmd);

	switch(type) {
				case to_host:
					{
						res = receive_dbg_packet(data);
					}
					break;
				case to_target:
					{
						res = send_dbg_packet();
					}
					break;
                                case to_target_cmd:
                                        {
                                                res = send_dbg_packet();
                                        }
                break;
				default :
					{
						return -1;
					}
	}

	if(res != data_size)
		return -1;
	else
		return 0;
}

////////////////////////////////////////////////////////////////////////////////

int packet485::request( unsigned short x, unsigned short y, unsigned char cmd )
{
	create_packet485( x, y, cmd );
	return send_main_packet();
}

////////////////////////////////////////////////////////////////////////////////

void packet485::reconnect_device(device *dev)
{
	if(dev) hw = dev;
}

////////////////////////////////////////////////////////////////////////////////

const struct packet packet485::get_packet()
{
	return p;
}

////////////////////////////////////////////////////////////////////////////////

