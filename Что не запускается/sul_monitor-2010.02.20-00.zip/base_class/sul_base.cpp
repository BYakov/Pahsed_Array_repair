#include "stdafx.h"
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>

#include <iostream>
#include <string>
#include <istream>
#include <fstream>
#include <iomanip>

#ifndef _SUL_BASE_H_
#include "sul_base.h"
#endif

using namespace std;

///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
//	         ���������� �������� ������ ���    	         //
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////

sul_base::sul_base(const char *flash_file, const char *ram_file) :
flash(flash_file),
ram(ram_file),
mode(mode_rk)
{
	cout << "sul_base::sul_base()" << endl;
	g_state.exch_err = 0;
	g_state.calc_err = 0;
	g_state.chan_err = 0;
}

///////////////////////////////////////////////////////////////////

sul_base::~sul_base()
{
	cout << "sul_base::~sul_base()" << endl;
	dev = NULL;
}

///////////////////////////////////////////////////////////////////

void sul_base::sul_set_mode(sul_mode m)
{
	mode = m;
}

///////////////////////////////////////////////////////////////////

void sul_base::sul_connect_device(device *hw)
{
	if(hw && (hw != dev)) dev = hw;
}

///////////////////////////////////////////////////////////////////

