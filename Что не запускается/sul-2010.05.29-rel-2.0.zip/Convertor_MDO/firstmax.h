//---------------------------------------------------------------------------

#ifndef firstmaxH
#define firstmaxH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Mask.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TButton *Button1;
        TLabel *Label3;
        TPanel *Panel1;
        TEdit *Edit4;
        TLabel *Label6;
        TEdit *Edit6;
        TLabel *Label8;
        TEdit *Edit7;
        TLabel *Label9;
        TLabel *Label13;
        TCheckBox *CheckBox4;
        TCheckBox *CheckBox5;
        TCheckBox *CheckBox6;
        TCheckBox *CheckBox7;
        TCheckBox *CheckBox8;
        TCheckBox *CheckBox9;
        TCheckBox *CheckBox10;
        TCheckBox *CheckBox11;
        TEdit *Edit17;
        TLabel *Label12;
        TEdit *Edit1;
        TEdit *Edit2;
        TEdit *Edit3;
        TEdit *Edit5;
        TEdit *Edit8;
        TEdit *Edit9;
        TEdit *Edit10;
        TEdit *Edit11;
        TLabel *Label2;
        TLabel *Label15;
        TLabel *Label24;
        TLabel *Label27;
        TLabel *Label28;
        TLabel *Label30;
        TLabel *Label10;
        TEdit *Edit12;
        TLabel *Label11;
        TEdit *Edit14;
        TEdit *Edit15;
        TEdit *Edit16;
        TEdit *Edit18;
        TEdit *Edit19;
        TEdit *Edit20;
        TEdit *Edit21;
        TEdit *Edit22;
        TEdit *Edit23;
        TEdit *Edit24;
        TEdit *Edit25;
        TEdit *Edit26;
        TEdit *Edit27;
        TEdit *Edit28;
        TEdit *Edit29;
        TEdit *Edit30;
        TEdit *Edit31;
        TEdit *Edit32;
        TEdit *Edit33;
        TEdit *Edit34;
        TEdit *Edit35;
        TEdit *Edit36;
        TLabel *Label4;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);
    void __fastcall Edit1KeyPress(TObject *Sender, char &Key);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
        void outfile(int [650]);
        void sfera(double,double,double,double,double);

        double  lambda, SX1, SX2, SX3, SX4, SX5, SX6, SX7, SX8,
            SY1, SY2, SY3, SY4, SY5, SY6, SY7, SY8, R1, R2, R3,
            R4, R5, R6, R7, R8, Kcant, Lambda1, Lambda2,
            Lambda3, Lambda4, Lambda5, Lambda6, Lambda7,
            Lambda8, F0_add;
        int CoordX[650], CoordY[650], F1[951], CORR1_128[650],
            CORR2_128[650],CORR3_128[650],CORR4_128[650],
            CORR5_128[650],CORR6_128[650],CORR7_128[650],
            CORR8_128[650],CANT_128[650];

        float F_eval[650], CORR1[650], CORR2[650], CORR3[650],
            CORR4[650], CORR5[650], CORR6[650], CORR7[650],
            CORR8[650], CANT[650],
            CORR1_F0[650], CORR2_F0[650], CORR3_F0[650], CORR4_F0[650],
            CORR5_F0[650], CORR6_F0[650], CORR7_F0[650], CORR8_F0[650],
            F0[650];

        FILE   *fid_outcorr,*fid_incant, *fid_inf0;

        BOOL err;
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif




