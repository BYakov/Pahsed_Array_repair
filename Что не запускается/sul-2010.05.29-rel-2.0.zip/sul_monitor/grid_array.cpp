#include "grid_array.h"

grid_array::grid_array(sul_base *Sul, QWidget *parent, Qt::WFlags flags)
: QWidget(parent, flags)
{
    setWindowTitle(tr("�������� �������"));

    bar = new QStatusBar(this);
    bar->setSizeGripEnabled(false);

    sul = Sul;

    int N = sul->sul_total_channels();

    x = new u8[N];
    y = new u8[N];

    memset(x,0,N);
    memset(y,0,N);

    maxX = 1;
    maxY = 1;

    // �������� ���������� ��� �������� ������
    for(int i=0; i<N; i++) {
        sul->sul_flash_get_element(9,0,i,x[i]);
        sul->sul_flash_get_element(10,0,i,y[i]);
        if(x[i] > maxX) maxX = x[i];
        if(y[i] > maxY) maxY = y[i];
    }

    memset(&shifter, 0, sizeof(struct phase_shifter));
    Radius = 10;
    abonent = 1;
}

//---------------------------------------------------------------------------------------

grid_array::~grid_array()
{
    close();

    if(x) delete [] x;
    if(y) delete [] y;
}

//---------------------------------------------------------------------------------------

void grid_array::paintEvent(QPaintEvent *event)
{
    float ScaleX = 0;
    float ScaleY = 0;

    float w = geometry().width()-3.5*Radius;
    float h = geometry().height()-3.8*Radius;

    ScaleX = w/maxX;
    ScaleY = h/maxY;

    QPainter p(this);
    QLinearGradient g(2.0*geometry().width(),geometry().height(),0,0);
    g.setSpread(QGradient::ReflectSpread);
    p.fillRect(0,0,geometry().width(),geometry().height(),QBrush(g));

    for(int i=0; i<sul->sul_total_channels(); i++) {

	if((x[i] == 0) && (y[i] == 0))
            continue;

	if(sul->sul_phase_shifter_info(i,shifter) < 0)
	    continue;

	switch(shifter.state) {
	case channel_operational: {
		QBrush b(Qt::green);
		p.setBrush(b);
		p.drawEllipse(ScaleX*x[i]+Radius,ScaleY*y[i]+Radius,Radius,Radius);
	    } break;
	case channel_open_fault: {
		QBrush b(Qt::red);
		p.setBrush(b);
		p.drawEllipse(ScaleX*x[i]+Radius,ScaleY*y[i]+Radius,Radius,Radius);
	    } break;
	case channel_short_circuit: {
		QBrush b(Qt::blue);
		p.setBrush(b);
		p.drawEllipse(ScaleX*x[i]+Radius,ScaleY*y[i]+Radius,Radius,Radius);
	    } break;
	case channel_untested:
	case channel_unconnected: {
		QBrush b(Qt::gray);
		p.setBrush(b);
		p.drawEllipse(ScaleX*x[i]+Radius,ScaleY*y[i]+Radius,Radius,Radius);
	    } break;
	}
    }
}

//---------------------------------------------------------------------------------------

void grid_array::mousePressEvent(QMouseEvent *event)
{
    float w = geometry().width()-3.5*Radius;
    float h = geometry().height()-3.8*Radius;

    float ScaleX = w/maxX;
    float ScaleY = h/maxY;

    int x = (event->x()-Radius)/ScaleX;
    int y = (event->y()-Radius)/ScaleY;

    QString s;

    if(sul->sul_phase_shifter_info(x,y,shifter) < 0) {
	s = tr("������������ ����� ������");
	bar->setGeometry(2,geometry().height()-15,geometry().width()-2,15);
	bar->showMessage(s);
	repaint();
	return;
    }
/*
    QString state;

    if(shifter.state == channel_operational) {
	state = tr(" ��������");
    } else {
	if(shifter.state == channel_untested) {
	    state = tr(" ����������");
	}
    }
*/
    s = tr("����� ") + QString::number(shifter.channel_number) +
	tr(", ��������� ") + QString::number(shifter.state, 16) +
	tr(", ������� ") + QString::number(shifter.line) +
	tr(", ������ ") + QString::number(shifter.abonent + 1) +
	tr(", ����������� X") + QString::number(shifter.connector + 1) +
	tr(", X ") + QString::number(shifter.x) +
	tr(", Y ") + QString::number(shifter.y);

    bar->setGeometry(2,geometry().height()-15,geometry().width()-2,15);
    bar->showMessage(s);
    repaint();
}

//---------------------------------------------------------------------------------------

void grid_array::set_abonent_number(int devn)
{
    abonent = devn;
}

//---------------------------------------------------------------------------------------
