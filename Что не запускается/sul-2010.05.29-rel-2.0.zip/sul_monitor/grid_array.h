#ifndef GRID_ARRAY_H
#define GRID_ARRAY_H

#include <QtGui>
#include <QtGui/QWidget>
#include <QTableView>
#include <QStatusBar>
#include <QSettings>
#include <QStandardItemModel>

#include "..\base_class\sul_base.h"

class grid_array : public QWidget
{
    Q_OBJECT
public:
    grid_array(sul_base *Sul, QWidget *parent, Qt::WFlags flags);
    virtual ~grid_array();
private:
    sul_base *sul;
    QStatusBar          *bar;
    u8                  *x;
    u8                  *y;
    u8                  maxX;
    u8                  maxY;
    int                 Radius;
    int			abonent;
    struct phase_shifter    shifter;

protected:
    void paintEvent(QPaintEvent *event);
    void mousePressEvent(QMouseEvent *event);

public slots:
	void set_abonent_number(int devn);
};

#endif // GRID_ARRAY_H
