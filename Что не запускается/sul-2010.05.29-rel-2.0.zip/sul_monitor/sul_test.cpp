
#include "sul_test.h"

#include <iostream>
#include <string>
#include <istream>
#include <fstream>
#include <iomanip>

using namespace std;

sul_test_widget::sul_test_widget(sul_base *s, QWidget *parent, Qt::WFlags flags):
	QWidget(parent,flags)
{
    setWindowTitle(tr("�������� �������"));

    QVBoxLayout *layout = new QVBoxLayout(this);
    label = new QLabel(tr("�������"));
    box = new QSpinBox();
    btnChannelTest = new QPushButton(tr("�������� �������"));
    btnCalculatorTest = new QPushButton(tr("�������� ������������"));
    btnExchangeTest = new QPushButton(tr("�������� ������"));
    btnChannels = new QPushButton(tr("������"));
    btnArray = new QPushButton(tr("�������"));
    bar = new QStatusBar();

    box->setValue(1);
    box->setMaximum(5);
    box->setMinimum(1);

    layout->addWidget(label);
    layout->addWidget(box);
    layout->addWidget(btnChannelTest);
    layout->addWidget(btnCalculatorTest);
    layout->addWidget(btnExchangeTest);
    layout->addWidget(btnArray);
    layout->addWidget(bar);

    connect(btnChannelTest,SIGNAL(clicked()),this,SLOT(test_channels()));
    connect(btnCalculatorTest,SIGNAL(clicked()),this,SLOT(test_calculators()));
    connect(btnExchangeTest,SIGNAL(clicked()),this,SLOT(test_exchange()));
    connect(btnChannels,SIGNAL(clicked()),this,SLOT(channels_show()));
    connect(btnArray,SIGNAL(clicked()),this,SLOT(grid_array_show()));
    connect(box,SIGNAL(valueChanged(int)),this,SLOT(abonent_changed(int)));

    sul = s;

    //setFixedSize(geometry().width(),geometry().height());
}

//-----------------------------------------------------------------------------

sul_test_widget::~sul_test_widget()
{
}

//-----------------------------------------------------------------------------

void sul_test_widget::test_channels()
{
    if(!sul) return;

    int abonent = box->value();

    cout << "sul_test_widget::test_channels() - abonent " << abonent << endl;

    if(sul->sul_test_channels(abonent) < 0) {
	    cout << "sul_test_widget::test_channels() - Error" << endl;
	    bar->showMessage(tr("������ ��������"));
	    return;
    }

    emit view_channels();

    bar->showMessage(tr("�������� ��������"));
}

//-----------------------------------------------------------------------------

void sul_test_widget::test_calculators()
{
    if(!sul) return;

    int abonent = box->value();

    cout << "sul_test_widget::test_calculators() - abonent " << abonent << endl;

    if(sul->sul_test_calculators(abonent) < 0) {
	    cout << "sul_test_widget::test_calculators() - Error" << endl;
	    bar->showMessage(tr("������ ��������"));
	    return;
    }

    emit view_calculators();

    bar->showMessage(tr("�������� ��������"));
}

//-----------------------------------------------------------------------------

void sul_test_widget::test_exchange()
{
    if(!sul) return;

    int abonent = box->value();
    int size = sul->sul_total_channels(abonent);

    unsigned char *buffer = (unsigned char *)malloc(size);
    if(!buffer)
	return;

    for(int i=0; i<size; i++)
	buffer[i] = i + 1;

    cout << "sul_test_widget::test_exchange() - abonent " << abonent << endl;

    if(sul->sul_test_exchange(abonent, buffer, size) < 0) {
	    cout << "sul_test_widget::test_exchange() - Error" << endl;
	    free(buffer);
	    bar->showMessage(tr("������ ��������"));
	    return;
    }

    free(buffer);

    bar->showMessage(tr("�������� ��������"));
}

//-----------------------------------------------------------------------------

void sul_test_widget::grid_array_show()
{
    emit view_grid_array();
}

//-----------------------------------------------------------------------------

void sul_test_widget::channels_show()
{
    emit view_channels();
}

//-----------------------------------------------------------------------------

void sul_test_widget::abonent_changed(int abonent)
{
    emit tested_abonent_changed(abonent);
}
