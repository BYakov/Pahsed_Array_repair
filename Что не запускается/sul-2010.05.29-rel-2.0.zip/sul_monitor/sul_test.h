#ifndef SUL_TEST_H
#define SUL_TEST_H

#include <QtGui>
#include <QtGui/QWidget>
#include <QTableView>
#include <QStatusBar>
#include <QSettings>
#include <QStandardItemModel>

#include "..\base_class\sul_base.h"

class sul_test_widget : public QWidget
{
	Q_OBJECT

private:
	sul_base *sul;

	QLabel *label;
	QSpinBox *box;
	QPushButton *btnChannelTest;
	QPushButton *btnCalculatorTest;
	QPushButton *btnExchangeTest;
        QPushButton *btnArray;
	QPushButton *btnChannels;
	QStatusBar  *bar;


public:
	sul_test_widget(sul_base *s, QWidget *parent = 0, Qt::WFlags flags = 0);
	virtual ~sul_test_widget();

signals:
	void view_channels();
	void view_grid_array();
	void view_calculators();
	void tested_abonent_changed(int abonent);

public slots:
	void test_exchange();
	void test_channels();
	void test_calculators();
        void grid_array_show();
	void channels_show();
	void abonent_changed(int);
};

#endif // SUL_TEST_H
