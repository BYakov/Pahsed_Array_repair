#include "sul_graph.h"

///////////////////////////////////////////////////////////////////////
//		����� ��� ��������� ��������� ���� (�� ���������)
///////////////////////////////////////////////////////////////////////

sul_graph::sul_graph(scanner *Scan, QWidget *parent, Qt::WFlags flags)
: QWidget(parent, flags)
{
	setWindowTitle(tr("������������ �����"));
	scan = Scan;
	//setFixedSize(geometry().width(),geometry().height());
}

//---------------------------------------------------------------------------------------

sul_graph::~sul_graph()
{
}

//---------------------------------------------------------------------------------------

void sul_graph::repaint()
{
	QWidget::repaint();
        if(!scan) return;
}

//---------------------------------------------------------------------------------------

void sul_graph::paintEvent(QPaintEvent *event)
{
	if(!scan)
		return;

	QRectF r = event->rect();

	float w = r.width();
	float h = r.height();
	float w0 = w/2;
	float h0 = h/2;

	float sc = w0/scan->get_rm();
	float xp = w0+sc*scan->get_x();
	float yp = h0-sc*scan->get_y();

	QPainter p(this);
        p.fillRect(0,0,w,h,QBrush(QLinearGradient(0,0,w,h)));
	p.setPen(Qt::black);
	p.drawLine(0,h/2,w,h/2);
	p.drawLine(w/2,0,w/2,h);
	p.drawEllipse(r);
	p.setPen(Qt::red);
	p.fillRect(xp,yp,5,5,QBrush(Qt::red,Qt::SolidPattern));
}

//---------------------------------------------------------------------------------------

void sul_graph::mousePressEvent(QMouseEvent *event)
{
    //float w = geometry().width();
    //float h = geometry().height();
    //float ScaleX = w/scan->get_rm();
    //float ScaleY = h/scan->get_rm();
}

//---------------------------------------------------------------------------------------
