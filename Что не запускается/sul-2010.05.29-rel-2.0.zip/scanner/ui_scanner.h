/********************************************************************************
** Form generated from reading UI file 'scanner.ui'
**
** Created: Sat 15. May 13:23:46 2010
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCANNER_H
#define UI_SCANNER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_scanner
{
public:
    QGroupBox *groupBox;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QSpinBox *portNum;
    QPushButton *btnStart;
    QPushButton *btnStop;
    QPushButton *btnPause;
    QPushButton *btnParse;
    QLabel *FmtCounter;
    QLabel *RawCounter;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;

    void setupUi(QWidget *scanner)
    {
        if (scanner->objectName().isEmpty())
            scanner->setObjectName(QString::fromUtf8("scanner"));
        scanner->resize(259, 199);
        groupBox = new QGroupBox(scanner);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(10, 10, 240, 160));
        gridLayoutWidget = new QWidget(groupBox);
        gridLayoutWidget->setObjectName(QString::fromUtf8("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(10, 18, 220, 138));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        portNum = new QSpinBox(gridLayoutWidget);
        portNum->setObjectName(QString::fromUtf8("portNum"));
        portNum->setValue(1);

        gridLayout->addWidget(portNum, 0, 0, 1, 1);

        btnStart = new QPushButton(gridLayoutWidget);
        btnStart->setObjectName(QString::fromUtf8("btnStart"));

        gridLayout->addWidget(btnStart, 1, 0, 1, 1);

        btnStop = new QPushButton(gridLayoutWidget);
        btnStop->setObjectName(QString::fromUtf8("btnStop"));

        gridLayout->addWidget(btnStop, 2, 0, 1, 1);

        btnPause = new QPushButton(gridLayoutWidget);
        btnPause->setObjectName(QString::fromUtf8("btnPause"));
        btnPause->setCheckable(true);

        gridLayout->addWidget(btnPause, 3, 0, 1, 1);

        btnParse = new QPushButton(gridLayoutWidget);
        btnParse->setObjectName(QString::fromUtf8("btnParse"));
        btnParse->setCheckable(false);

        gridLayout->addWidget(btnParse, 4, 0, 1, 1);

        FmtCounter = new QLabel(gridLayoutWidget);
        FmtCounter->setObjectName(QString::fromUtf8("FmtCounter"));
        FmtCounter->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(FmtCounter, 4, 2, 1, 1);

        RawCounter = new QLabel(gridLayoutWidget);
        RawCounter->setObjectName(QString::fromUtf8("RawCounter"));
        RawCounter->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(RawCounter, 2, 2, 1, 1);

        label = new QLabel(gridLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label, 1, 2, 1, 1);

        label_2 = new QLabel(gridLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_2, 3, 2, 1, 1);

        label_3 = new QLabel(gridLayoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_3, 0, 2, 1, 1);


        retranslateUi(scanner);

        QMetaObject::connectSlotsByName(scanner);
    } // setupUi

    void retranslateUi(QWidget *scanner)
    {
        scanner->setWindowTitle(QApplication::translate("scanner", "scanner", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("scanner", "\320\234\320\276\320\275\320\270\321\202\320\276\321\200 RS-485", 0, QApplication::UnicodeUTF8));
        btnStart->setText(QApplication::translate("scanner", "\320\241\321\202\320\260\321\200\321\202", 0, QApplication::UnicodeUTF8));
        btnStop->setText(QApplication::translate("scanner", "\320\241\321\202\320\276\320\277", 0, QApplication::UnicodeUTF8));
        btnPause->setText(QApplication::translate("scanner", "\320\237\320\260\321\203\320\267\320\260", 0, QApplication::UnicodeUTF8));
        btnParse->setText(QApplication::translate("scanner", "\320\220\320\275\320\260\320\273\320\270\320\267", 0, QApplication::UnicodeUTF8));
        FmtCounter->setText(QApplication::translate("scanner", "0", 0, QApplication::UnicodeUTF8));
        RawCounter->setText(QApplication::translate("scanner", "0", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("scanner", "\320\237\320\276\320\273\321\203\321\207\320\265\320\275\320\276 \320\261\320\260\320\271\321\202:", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("scanner", "\320\236\320\261\321\200\320\260\320\261\320\276\321\202\320\260\320\275\320\276 \320\261\320\260\320\271\321\202:", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("scanner", "\320\241\321\202\320\260\321\202\320\270\321\201\321\202\320\270\320\272\320\260", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class scanner: public Ui_scanner {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCANNER_H
