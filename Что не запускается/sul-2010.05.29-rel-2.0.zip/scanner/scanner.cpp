#include <iostream>
#include <string>
#include <istream>
#include <fstream>
#include <iomanip>

using namespace std;

#include "scanner.h"
#include "ui_scanner.h"

//-----------------------------------------------------------------------------

QString cmd_to_string(int cmd)
{
    switch (cmd) {
            case host_eeprom_data: return QString("host_eeprom_data");
            case host_ram_data: return QString("host_ram_data");
            case host_scale: return QString("host_scale");
            case target_scale_return: return QString("target_scale_return");
            case target_eeprom_clear: return QString("target_eeprom_clear");
            case target_ram_clear: return QString("target_ram_clear");
            case target_eeprom_to_plm: return QString("target_eeprom_to_plm");
            case target_ram_to_plm: return QString("target_ram_to_plm");
            case target_eeprom_data: return QString("target_eeprom_data");
            case target_ram_data: return QString("target_ram_data");
            case target_eeprom_crc: return QString("target_eeprom_crc");
            case target_ram_crc: return QString("target_ram_crc");
            case target_ctrl_impulse: return QString("target_ctrl_impulse");
            case target_impulse_return: return QString("target_impulse_return");
            case target_ctrl_channel: return QString("target_ctrl_channel");
            case target_channel_return: return QString("target_channel");
            case target_ctrl_calc: return QString("target_ctrl_calc");
            case target_calc_return: return QString("target_calc_return");
            case host_to_target: return QString("host_to_target");
            case target_to_host: return QString("target_to_host");
            case target_address: return QString("target_address");
    }
    return QString("�������� ���");
}

//-----------------------------------------------------------------------------

QString type_to_string(int type)
{
    switch (type) {
            case to_target: return QString("to_target");
            case to_host: return QString("to_host");
            case to_target_cmd: return QString("to_target_cmd");
    }
    return QString("�������� ���");
}

//-----------------------------------------------------------------------------

scanner::scanner(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::scanner)
{
    QTextCodec::setCodecForTr(QTextCodec::codecForName("Windows-1251"));

    ui->setupUi(this);

    bar = new QStatusBar(this);

    connect(ui->btnStart,SIGNAL(clicked()),this,SLOT(start()));
    connect(ui->btnStop,SIGNAL(clicked()),this,SLOT(stop()));
    connect(ui->btnPause,SIGNAL(clicked()),this,SLOT(pause()));
    connect(ui->btnParse,SIGNAL(clicked()),this,SLOT(parse()));

    scan = NULL;
    parser = NULL;
    hw = NULL;

    int H = geometry().height();
    int W = geometry().width();
    bar->setGeometry(5,H-20,W-5,16);

    bar->showMessage(tr("������������� ���������"));
    bar->show();

    settings = new QSettings( "scanner.cfg", QSettings::IniFormat );
    QVariant port = settings->value("COM", "1");
    ui->portNum->setValue(port.toInt());
}

//-----------------------------------------------------------------------------

scanner::~scanner()
{
    settings->setValue("COM", ui->portNum->value());

    if(scan) {
        delete scan;
        scan = NULL;
    }

    if(parser) {
        delete parser;
        parser = NULL;
    }

    delete settings;

    delete ui;
}

//-----------------------------------------------------------------------------

void scanner::raw_update(int N)
{
    ui->RawCounter->setText(QString::number(N,10));
}

//-----------------------------------------------------------------------------

void scanner::changeEvent(QEvent *e)
{
    QWidget::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

//-----------------------------------------------------------------------------

int scanner::open()
{
    cout << "open()" << endl;

    if(hw)
        return 0;

    QString name("COM"+QString::number(ui->portNum->value()));

    hw = new serial(name.toAscii(),0);
    if(!hw->is_open()) {
        delete hw;
        hw = NULL;
        bar->showMessage(tr("������ �������� �����: ") + name);
        return -1;
    }

    bar->showMessage(tr("����: ")  + name + tr(" ������"));

    return 0;
}

//-----------------------------------------------------------------------------

int scanner::close()
{
    cout << "close()" << endl;
    if(hw) {
        delete hw;
        hw = NULL;
    }

    QString name("COM"+QString::number(ui->portNum->value()));
    bar->showMessage(tr("����: ") + name + tr(" ������"));

    return 0;
}

//-----------------------------------------------------------------------------

void scanner::start()
{
    if(scan) {
        return;
    }

    if(!hw) {
        if(open() < 0) {
            bar->showMessage(tr("���� �� ������!"));
            return;
        }
    }

    scan = new scanner_thread(hw);

    connect(scan,SIGNAL(raw_bytes_read(int)),this,SLOT(raw_update(int)));

    scan->start_thread(QThread::HighestPriority);

    if(scan->isRunning()) {
        bar->showMessage(tr("�����������..."));
    } else {
        bar->showMessage(tr("��������..."));
    }
}

//-----------------------------------------------------------------------------

void scanner::stop()
{
    if(!scan) {
        return;
    }

    scan->stop_thread();

    scan->wait(500);

    if(scan->isFinished()) {
        bar->showMessage(tr("����������� �����������"));
    } else {
        bar->showMessage(tr("������ ���������!"));
    }

    delete scan;
    scan = NULL;

    if(hw) {
        if(close()<0) {
            bar->showMessage(tr("���� �� ������!"));
            return;
        }
        hw = NULL;
    }
}

//-----------------------------------------------------------------------------

void scanner::pause()
{
    if(!scan) {
        return;
    }

    if(ui->btnPause->isChecked()) {
        scan->pause_thread(true);
        bar->showMessage(tr("�����..."));
    } else {
        scan->pause_thread(false);
        bar->showMessage(tr("�����������..."));
    }
}

//-----------------------------------------------------------------------------

void scanner::parse()
{
    if(scan) {
        if(scan->isRunning()) {
            bar->showMessage(tr("���� �����������!"));
            return;
        }
    }

    if(!parser) {
        parser = new raw_parser("protocol.raw");
    }

    int N = parser->parse_raw_file("protocol.fmt","protocol.raw");

    ui->FmtCounter->setText(QString::number(N));

    bar->showMessage(tr("������ ��������"));
}

//-----------------------------------------------------------------------------

scanner_thread::scanner_thread( device *hw )
{
    init_ok = false;
    exit_ok = true;
    paused = true;

    if(!hw) {
        dev = NULL;
        cout << "Invalid device object" << endl;
        return;
    }

    dev = hw;
    init_ok = true;
}

//-----------------------------------------------------------------------------

scanner_thread::~scanner_thread()
{
    if(isRunning()) {
        stop_thread();
        wait();
    }
}

//-----------------------------------------------------------------------------

void scanner_thread::run()
{
    cout << "scanner_thread::run()" << endl;

    if(!init_ok)
        return;

    setTerminationEnabled(false);

    unsigned char data = 0;
    int index = 0;
    fstream  ofs;

    ofs.open( "protocol.raw", ios::out );
    if (!ofs.is_open()) {
            cout << "Error open file" << endl;
            return;
    }

    ofs << "[Registrated RS-485 raw data]" << endl;

    while(!exit_ok) {

        if(paused) {
            cout << "pause = " << paused << endl;
            msleep(10);
            continue;
        }

        // ����� ������� ����� � ����� �� ��� �������� ������� "��� ������" (�) ������������
        int nBytes = dev->read_data(&data,sizeof(data),10);
        if(nBytes <= 0) {
           cout << " nBytes = " << nBytes << endl;
           msleep(10);
           continue;
        }

        index += nBytes;

        ofs << dec << setw(2) << int(data) << " ";

        emit raw_bytes_read(index);
    }

    ofs.close();

    terminate();

    emit raw_bytes_read(0);
}

//-----------------------------------------------------------------------------

void scanner_thread::start_thread( Priority priority )
{
    cout << "scanner_thread::start_thread()" << endl;
    exit_ok = false;
    paused = false;
    QThread::start(priority);
}

//-----------------------------------------------------------------------------

void scanner_thread::stop_thread()
{
    cout << "scanner_thread::stop_thread()" << endl;
    setTerminationEnabled(true);
    exit_ok = true;
}

//-----------------------------------------------------------------------------

void scanner_thread::pause_thread(bool state)
{
    cout << "pause = " << state << endl;
    paused = state;
}

//-----------------------------------------------------------------------------

int scanner_thread::print_target_header(fstream &ofs)
{
        unsigned char data = 0;

        cout << "print_target_header()" << endl;

        ofs << dec << endl;
        ofs << "signature:    " << int(target_signature) << endl;
        dev->read_data(&data,sizeof(data),10);
        ofs << "address:      " << int(data) << endl;
        dev->read_data(&data,sizeof(data),10);
        ofs << "code:         " << cmd_to_string(data).toAscii().data() << " (" << int(data) << ")" << endl;
        ofs << "data CRC:     " << int(data) << endl;
        ofs << endl;


        return sizeof(struct target_dbg_header)-1;
}

//-----------------------------------------------------------------------------

int scanner_thread::print_host_header(fstream &ofs)
{
        unsigned char data = 0;
        int N = 0;

        cout << "print_dbg_header()" << endl;

        ofs << dec << endl;
        ofs << "signature:    " << int(host_signature) << endl;
        dev->read_data(&data,sizeof(data),10);
        ofs << "address:      " << int(data) << endl;
        dev->read_data(&data,sizeof(data),10);
        ofs << "code:         " << cmd_to_string(data).toAscii().data() << " (" << int(data) << ")" << endl;
        dev->read_data(&data,sizeof(data),10);
        ofs << "data size:    " << int(data) << endl; N = data;
        dev->read_data(&data,sizeof(data),10);
        ofs << "data CRC:     " << int(data) << endl;
        dev->read_data(&data,sizeof(data),10);
        ofs << "block number: " << int(data) << endl;
        dev->read_data(&data,sizeof(data),10);
        ofs << "tx/rx:        " << type_to_string(int(data)).toAscii().data() << " (" << int(data) << ")" << endl;
        dev->read_data(&data,sizeof(data),10);
        ofs << "header CRC:   " << int(data) << endl;
        ofs << endl;

        for(int j=0; j<N; ++j) {

            if((j%16) == 0) ofs << endl;

            dev->read_data(&data,sizeof(data),10);

            ofs << dec << setw(3) << int(data) << " " ;
        }

        ofs << endl;

        return sizeof(struct host_dbg_header) + N;
}

//-----------------------------------------------------------------------------
/*
int scanner_thread::print_main_header(fstream &ofs)
{
        unsigned char data = 0;
        unsigned short X = 0;
        unsigned short Y = 0;

        cout << "print_main_header()" << endl;

        ofs << dec << endl;
        ofs << "signature: " << dec << int(host_signature) << endl;
        dev->read_data(&data,sizeof(data),10);
        ofs << "address:   " << dec << int(data) << " (all)" << endl;
        dev->read_data(&X,sizeof(X),10);
        ofs << "X:         " << hex << int(X) << endl;
        dev->read_data(&Y,sizeof(Y),10);
        ofs << "Y:         " << hex << int(Y) << endl;
        dev->read_data(&data,sizeof(data),10);
        ofs << "cmd:       " << dec << int(data) << endl;
        ofs << "CRC:       " << dec << int(data) << endl;

        return sizeof(struct main_packet);
}
*/
//-----------------------------------------------------------------------------

int scanner_thread::print_data(fstream &ofs, int N)
{
    unsigned char data = 0;

    for(int j=0; j<N; ++j) {

       if((j%16) == 0) ofs << endl;

       ofs << dec << setw(3) << int(data) << " " ;
    }

    ofs << endl;

    return N;
}

//-----------------------------------------------------------------------------

int scanner_thread::print_error(fstream &ofs )
{
    ofs << endl;
    ofs << "ERROR COMPLETE REQUEST" << endl;
    ofs << endl;

    return 0;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

raw_parser::raw_parser(const char *rawfile) : space(rawfile)
{
    cout << "raw_parser()" << endl;
}

//-----------------------------------------------------------------------------

raw_parser::~raw_parser()
{
    cout << "~raw_parser()" << endl;
}

//-----------------------------------------------------------------------------

int raw_parser::parse_raw_file(const char *fmtfile, const char *rawfile)
{
    unsigned char		*mem = NULL;
    struct host_dbg_header	*h = NULL;
    struct target_dbg_header	*t = NULL;
    u8				data = 0;
    int				res = 0;
    fstream			ofs;

    if(rawfile) {
        if(space_reconfig_memory(rawfile) < 0) {
            cout << "Posibble empty raw data file" << endl;
            return 0;
        }
    }

    ofs.open( fmtfile, ios::out );
    if (!ofs.is_open()) {
            cout << "Error open file" << fmtfile << endl;
            return -1;
    }

    if(info.total_size != 0) {
        mem = (unsigned char*)malloc(info.total_size);
        if(!mem) {
            cout << "Error allocate memory" << endl;
            return -2;
        }
    }

    for(int i=0; i<info.total_size; i++) {

        res = space_get_element(0, 0, i, data);
        if(res < 0) {
            cout << "space_get_element() error" << endl;
            free(mem);
            return -2;
        }

        mem[i] = data;
    }

    int N = 0;
    int i = 0;
    for(i=0; i<info.total_size; ++i) {

        //cout << "mem[i] = " << int(mem[i]) << endl;
        //cout << "mem[i+1] = " << int(mem[i+1]) << endl;

        if(mem[i] == host_signature) {

            h  = (struct host_dbg_header*)&mem[i];

            if(h->addr != 0) {

                N = h->size;
                i += print_host_header(ofs, h);

            }

        } else {

            if(mem[i] == target_signature) {

                t  = (struct target_dbg_header*)&mem[i];
                i += print_target_header(ofs, t);

            } else {
                continue;
            }
        }

        if((i+1 == info.total_size) && (h->txrx == to_host) && N) {
            N = print_error(ofs);
        }

        if((mem[i+1] == host_signature) && (h->txrx == to_host) && N) {
            //������� �� ������� ������ ������ ����� ��������� ��������� ����
            N = print_error(ofs);
        }

        if(N) {
            //������ ������
            i += print_data(ofs,h,&mem[i+1],N);
            N = 0;
        }
    }

    ofs.close();

    free(mem);

    return i;
}

//-----------------------------------------------------------------------------

int raw_parser::print_target_header(fstream &ofs, struct target_dbg_header *hdr)
{
        cout << "print_target_header()" << endl;
        ofs << dec << endl;
        ofs << "signature:    " << int(hdr->sign) << endl;
        ofs << "address:      " << int(hdr->addr) << endl;
        ofs << "code:         " << cmd_to_string(hdr->code).toAscii().data() << " (" << int(hdr->code) << ")" << endl;
        ofs << "data CRC:     " << int(hdr->crc) << endl;
        ofs << endl;
        return sizeof(struct target_dbg_header)-1;
}

//-----------------------------------------------------------------------------

int raw_parser::print_host_header(fstream &ofs, struct host_dbg_header *hdr)
{
        cout << "print_dbg_header()" << endl;
        ofs << dec << endl;
        ofs << "signature:    " << int(hdr->sign) << endl;
        ofs << "address:      " << int(hdr->addr) << endl;
        ofs << "code:         " << cmd_to_string(hdr->code).toAscii().data() << " (" << int(hdr->code) << ")" << endl;
        ofs << "data size:    " << int(hdr->size) << endl;
        ofs << "data CRC:     " << int(hdr->dcrc) << endl;
        ofs << "block number: " << int(hdr->bnum) << endl;
        ofs << "tx/rx:        " << type_to_string(int(hdr->txrx)).toAscii().data() << " (" << int(hdr->txrx) << ")" << endl;
        ofs << "header CRC:   " << int(hdr->hcrc) << endl;
        ofs << endl;
        return sizeof(struct host_dbg_header)-1;
}

//-----------------------------------------------------------------------------

int raw_parser::print_main_header(fstream &ofs, struct main_packet *mhdr)
{
        cout << "print_main_header()" << endl;
        ofs << dec << endl;
        ofs << "signature: " << dec << int(mhdr->mhdr.sign) << endl;
        ofs << "address:   " << dec << int(mhdr->mhdr.addr) << " (all)" << endl;
        ofs << "X:         " << hex << int(mhdr->mdata.x) << endl;
        ofs << "Y:         " << hex << int(mhdr->mdata.y) << endl;
        ofs << "cmd:       " << dec << int(mhdr->mdata.cmd) << endl;
        ofs << "CRC:       " << dec << int(mhdr->mtail.mcrc) << endl;
        return sizeof(struct main_packet)-1;
}

//-----------------------------------------------------------------------------

int raw_parser::print_data(fstream &ofs, struct host_dbg_header *hdr, unsigned char *data, int N)
{
    if(hdr->txrx == to_target)
        ofs << "HOST -> ABONENT (" << int(hdr->size) << ")" << endl;
    else
        ofs << "ABONENT -> HOST (" << int(hdr->size) << ")" << endl;

    for(int j=0; j<N; ++j) {

       if((j%16) == 0) ofs << endl;

       ofs << dec << setw(3) << int(data[j]) << " " ;
    }

    ofs << endl;

    return N-1;
}

//-----------------------------------------------------------------------------

int raw_parser::print_error(fstream &ofs, int error_type )
{
    ofs << endl;
    ofs << "ERROR COMPLETE REQUEST" << endl;
    ofs << endl;

    return 0;
}

//-----------------------------------------------------------------------------

QString raw_parser::cmd_to_string(int cmd)
{
    switch (cmd) {
            case host_eeprom_data: return QString("host_eeprom_data");
            case host_ram_data: return QString("host_ram_data");
            case target_eeprom_clear: return QString("target_eeprom_clear");
            case target_ram_clear: return QString("target_ram_clear");
            case target_eeprom_to_plm: return QString("target_eeprom_to_plm");
            case target_ram_to_plm: return QString("target_ram_to_plm");
            case target_eeprom_data: return QString("target_eeprom_data");
            case target_ram_data: return QString("target_ram_data");
            case target_eeprom_crc: return QString("target_eeprom_crc");
            case target_ram_crc: return QString("target_ram_crc");
            case target_ctrl_impulse: return QString("target_ctrl_impulse");
            case target_impulse_return: return QString("target_impulse_return");
            case target_ctrl_channel: return QString("target_ctrl_channel");
            case target_channel_return: return QString("target_channel");
            case target_ctrl_calc: return QString("target_ctrl_calc");
            case target_calc_return: return QString("target_calc_return");
            case host_to_target: return QString("host_to_target");
            case target_to_host: return QString("target_to_host");
            case target_address: return QString("target_address");
    }
    return QString("�������� ���");
}

//-----------------------------------------------------------------------------

QString raw_parser::type_to_string(int type)
{
    switch (type) {
            case to_target: return QString("to_target");
            case to_host: return QString("to_host");
            case to_target_cmd: return QString("to_target_cmd");
    }
    return QString("�������� ���");
}
