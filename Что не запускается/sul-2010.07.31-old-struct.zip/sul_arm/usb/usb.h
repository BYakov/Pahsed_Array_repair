
#ifndef _USB_H_
#define _USB_H_

void USB_Init(void);

#endif //_USB_H_
