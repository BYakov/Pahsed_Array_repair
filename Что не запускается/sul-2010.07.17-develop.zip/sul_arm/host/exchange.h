
#ifndef _EXCHANGE_H_
#define _EXCHANGE_H_

enum {
    dma_token_sign = 0x77,
};

struct dma_token {
    unsigned char sign;
    unsigned char size;
    unsigned char code;
    unsigned char data;
    unsigned char dcrc;
    unsigned char tcrc;
};

enum {
    usart_debug_msg = 0x55,
};

unsigned char token_crc(struct dma_token *token);
unsigned char data_crc(unsigned char *data, int size);
void init_dma_token(struct dma_token *token, unsigned char data, unsigned char *buffer, int size);
int check_dma_token(struct dma_token *token);
int check_dma_transactions(struct dma_token *token, unsigned char *buffer, int size);

#endif //_EXCHANGE_H_
