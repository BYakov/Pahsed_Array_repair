#ifndef WIDGET_H
#define WIDGET_H

#include <QtGui>
#include <QtGui/QWidget>
#include <QTableView>
#include <QStatusBar>
#include <QSettings>
#include <QStandardItemModel>


#include "..\..\sul_src\serial.h"
#include "exchange.h"

namespace Ui {
    class Widget;
}

struct host_data {
    unsigned char data[10];
};

class Widget : public QWidget {
    Q_OBJECT
public:
    Widget(QWidget *parent = 0);
    ~Widget();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::Widget          *ui;
    struct dma_token    token;
    struct host_data    packet;
    device              *port;
    QStatusBar          *bar;
    QTimer              *timer;
    int                 transfer_bytes;
    unsigned char       counter;
    int preamble(int size, int code, unsigned char data, unsigned char *buffer);

public slots:
    void start_timer();
    void timer_event();
};

#endif // WIDGET_H
