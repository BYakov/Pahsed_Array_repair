/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created: Sat 17. Jul 13:14:24 2010
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *mainLayout;
    QGroupBox *groupBox;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QLabel *label;
    QLabel *label_3;
    QSpinBox *spbCommand;
    QLabel *label_4;
    QSpinBox *spbX;
    QLabel *label_5;
    QSpinBox *spbY;
    QLabel *label_6;
    QSpinBox *spbCtrl;
    QLabel *label_2;
    QSpinBox *periodVal;
    QSpinBox *spbMode;
    QPushButton *btnStart;
    QGroupBox *groupBox_2;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_7;
    QSpinBox *spbUsartID;
    QLabel *label_8;
    QSpinBox *spbUsartCtrl;
    QLabel *label_9;
    QSpinBox *spbNumBytes;
    QLabel *label_10;
    QSpinBox *spbUsartD0;
    QSpinBox *spbUsartD1;
    QSpinBox *spbUsartD2;
    QSpinBox *spbUsartD3;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(412, 299);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Widget->sizePolicy().hasHeightForWidth());
        Widget->setSizePolicy(sizePolicy);
        verticalLayoutWidget_2 = new QWidget(Widget);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(5, 270, 401, 25));
        mainLayout = new QVBoxLayout(verticalLayoutWidget_2);
        mainLayout->setSpacing(6);
        mainLayout->setContentsMargins(5, 5, 5, 5);
        mainLayout->setObjectName(QString::fromUtf8("mainLayout"));
        mainLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        mainLayout->setContentsMargins(0, 0, 0, 0);
        groupBox = new QGroupBox(Widget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(5, 5, 244, 261));
        QSizePolicy sizePolicy1(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy1);
        gridLayoutWidget = new QWidget(groupBox);
        gridLayoutWidget->setObjectName(QString::fromUtf8("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(10, 20, 225, 235));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setSpacing(5);
        gridLayout->setContentsMargins(5, 5, 5, 5);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(gridLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label, 0, 0, 1, 1);

        label_3 = new QLabel(gridLayoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        spbCommand = new QSpinBox(gridLayoutWidget);
        spbCommand->setObjectName(QString::fromUtf8("spbCommand"));
        spbCommand->setMinimum(1);

        gridLayout->addWidget(spbCommand, 1, 0, 1, 1);

        label_4 = new QLabel(gridLayoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_4, 4, 0, 1, 1);

        spbX = new QSpinBox(gridLayoutWidget);
        spbX->setObjectName(QString::fromUtf8("spbX"));

        gridLayout->addWidget(spbX, 5, 0, 1, 1);

        label_5 = new QLabel(gridLayoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_5, 6, 0, 1, 1);

        spbY = new QSpinBox(gridLayoutWidget);
        spbY->setObjectName(QString::fromUtf8("spbY"));

        gridLayout->addWidget(spbY, 7, 0, 1, 1);

        label_6 = new QLabel(gridLayoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_6, 8, 0, 1, 1);

        spbCtrl = new QSpinBox(gridLayoutWidget);
        spbCtrl->setObjectName(QString::fromUtf8("spbCtrl"));

        gridLayout->addWidget(spbCtrl, 9, 0, 1, 1);

        label_2 = new QLabel(gridLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_2, 0, 1, 1, 1);

        periodVal = new QSpinBox(gridLayoutWidget);
        periodVal->setObjectName(QString::fromUtf8("periodVal"));
        periodVal->setMaximum(5000);
        periodVal->setSingleStep(10);

        gridLayout->addWidget(periodVal, 1, 1, 1, 1);

        spbMode = new QSpinBox(gridLayoutWidget);
        spbMode->setObjectName(QString::fromUtf8("spbMode"));

        gridLayout->addWidget(spbMode, 3, 0, 1, 1);

        btnStart = new QPushButton(gridLayoutWidget);
        btnStart->setObjectName(QString::fromUtf8("btnStart"));

        gridLayout->addWidget(btnStart, 9, 1, 1, 1);

        groupBox_2 = new QGroupBox(Widget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(255, 5, 151, 261));
        verticalLayoutWidget = new QWidget(groupBox_2);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(15, 20, 121, 235));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(2);
        verticalLayout->setContentsMargins(5, 5, 5, 5);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(verticalLayoutWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout->addWidget(label_7);

        spbUsartID = new QSpinBox(verticalLayoutWidget);
        spbUsartID->setObjectName(QString::fromUtf8("spbUsartID"));
        spbUsartID->setMaximum(32);
        spbUsartID->setValue(1);

        verticalLayout->addWidget(spbUsartID);

        label_8 = new QLabel(verticalLayoutWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout->addWidget(label_8);

        spbUsartCtrl = new QSpinBox(verticalLayoutWidget);
        spbUsartCtrl->setObjectName(QString::fromUtf8("spbUsartCtrl"));
        spbUsartCtrl->setValue(32);

        verticalLayout->addWidget(spbUsartCtrl);

        label_9 = new QLabel(verticalLayoutWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        verticalLayout->addWidget(label_9);

        spbNumBytes = new QSpinBox(verticalLayoutWidget);
        spbNumBytes->setObjectName(QString::fromUtf8("spbNumBytes"));
        spbNumBytes->setMinimum(1);
        spbNumBytes->setMaximum(4);
        spbNumBytes->setSingleStep(1);
        spbNumBytes->setValue(1);

        verticalLayout->addWidget(spbNumBytes);

        label_10 = new QLabel(verticalLayoutWidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        verticalLayout->addWidget(label_10);

        spbUsartD0 = new QSpinBox(verticalLayoutWidget);
        spbUsartD0->setObjectName(QString::fromUtf8("spbUsartD0"));
        spbUsartD0->setValue(1);

        verticalLayout->addWidget(spbUsartD0);

        spbUsartD1 = new QSpinBox(verticalLayoutWidget);
        spbUsartD1->setObjectName(QString::fromUtf8("spbUsartD1"));
        spbUsartD1->setValue(2);

        verticalLayout->addWidget(spbUsartD1);

        spbUsartD2 = new QSpinBox(verticalLayoutWidget);
        spbUsartD2->setObjectName(QString::fromUtf8("spbUsartD2"));
        spbUsartD2->setValue(3);

        verticalLayout->addWidget(spbUsartD2);

        spbUsartD3 = new QSpinBox(verticalLayoutWidget);
        spbUsartD3->setObjectName(QString::fromUtf8("spbUsartD3"));
        spbUsartD3->setValue(4);

        verticalLayout->addWidget(spbUsartD3);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("Widget", "\320\237\321\200\320\276\321\202\320\276\320\272\320\276\320\273 \320\276\320\261\320\274\320\265\320\275\320\260", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Widget", "\320\232\320\276\320\264 \320\272\320\276\320\274\320\260\320\275\320\264\321\213", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("Widget", "\320\240\320\265\320\266\320\270\320\274", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("Widget", "\320\235\320\260\320\261\320\265\320\263 X", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("Widget", "\320\235\320\260\320\261\320\265\320\263 Y", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("Widget", "\320\232\320\276\320\275\321\202\321\200\320\276\320\273\321\214", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Widget", "\320\237\320\265\321\200\320\270\320\276\320\264", 0, QApplication::UnicodeUTF8));
        btnStart->setText(QApplication::translate("Widget", "\320\241\321\202\320\260\321\200\321\202", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("Widget", "\320\236\321\202\320\273\320\260\320\264\320\272\320\260 USART", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("Widget", "\320\235\320\276\320\274\320\265\321\200 USART", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("Widget", "\320\243\320\277\321\200\320\260\320\262\320\273\321\217\321\216\321\211\320\265\320\265 \321\201\320\273\320\276\320\262\320\276", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("Widget", "\320\232\320\276\320\273\320\270\321\207\320\265\321\201\321\202\320\262\320\276 \320\261\320\260\320\271\321\202 ", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("Widget", "\320\224\320\260\320\275\320\275\321\213\320\265", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
