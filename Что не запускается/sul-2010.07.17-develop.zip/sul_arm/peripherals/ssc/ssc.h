
#ifndef _SSC_H_
#define _SSC_H_

void SSC_Configure(void);
void SSC_Write(unsigned int frame);
unsigned int SSC_Read(void);

#endif //_SSC_H_
