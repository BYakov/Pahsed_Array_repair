/****************************************************************************
** Meta object code from reading C++ file 'sul_monitor.h'
**
** Created: Sat 5. Jun 17:10:03 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../sul_monitor.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'sul_monitor.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_sul_monitor[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
      46,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x0a,
      29,   12,   12,   12, 0x0a,
      44,   12,   12,   12, 0x0a,
      59,   12,   12,   12, 0x0a,
      73,   12,   12,   12, 0x0a,
      85,   12,   12,   12, 0x0a,
      97,   12,   12,   12, 0x0a,
     109,   12,   12,   12, 0x0a,
     124,   12,   12,   12, 0x0a,
     140,   12,   12,   12, 0x0a,
     160,   12,   12,   12, 0x0a,
     174,   12,   12,   12, 0x0a,
     188,   12,   12,   12, 0x0a,
     209,  203,   12,   12, 0x0a,
     226,   12,   12,   12, 0x2a,
     240,  203,   12,   12, 0x0a,
     254,   12,   12,   12, 0x2a,
     265,  203,   12,   12, 0x0a,
     281,   12,   12,   12, 0x2a,
     294,   12,   12,   12, 0x0a,
     316,   12,   12,   12, 0x0a,
     342,   12,   12,   12, 0x0a,
     360,   12,   12,   12, 0x0a,
     383,   12,   12,   12, 0x0a,
     397,   12,   12,   12, 0x0a,
     410,   12,   12,   12, 0x0a,
     424,   12,   12,   12, 0x0a,
     437,   12,   12,   12, 0x0a,
     451,   12,   12,   12, 0x0a,
     461,   12,   12,   12, 0x0a,
     477,   12,   12,   12, 0x0a,
     493,   12,   12,   12, 0x0a,
     504,   12,   12,   12, 0x0a,
     516,   12,   12,   12, 0x0a,
     527,   12,   12,   12, 0x0a,
     538,   12,   12,   12, 0x0a,
     559,   12,   12,   12, 0x0a,
     583,   12,   12,   12, 0x0a,
     609,   12,   12,   12, 0x0a,
     628,   12,   12,   12, 0x0a,
     649,  642,   12,   12, 0x0a,
     672,   12,   12,   12, 0x0a,
     694,   12,   12,   12, 0x0a,
     719,  715,   12,   12, 0x0a,
     737,  715,   12,   12, 0x0a,
     765,   12,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_sul_monitor[] = {
    "sul_monitor\0\0start_scanner()\0"
    "stop_scanner()\0step_scanner()\0"
    "set_scanner()\0dr_change()\0x0_change()\0"
    "y0_change()\0angle_change()\0sector_change()\0"
    "sector_max_change()\0axis_change()\0"
    "timer_event()\0iface_change()\0index\0"
    "tool_change(int)\0tool_change()\0"
    "fill_ram(int)\0fill_ram()\0fill_flash(int)\0"
    "fill_flash()\0detect_abonent_list()\0"
    "prepare_abonent_request()\0dbg_timer_event()\0"
    "send_abonent_request()\0zone_change()\0"
    "open_flash()\0erase_flash()\0load_flash()\0"
    "check_flash()\0set_ram()\0inc_ram_value()\0"
    "dec_ram_value()\0open_ram()\0erase_ram()\0"
    "load_ram()\0save_ram()\0show_beam_position()\0"
    "show_channells_status()\0"
    "show_calculators_status()\0show_phase_array()\0"
    "test_widget()\0status\0processing_status(int)\0"
    "display_timer_event()\0set_antenna_params()\0"
    "val\0set_dbgtimer(int)\0update_abonent_address(int)\0"
    "new_cfg_file_create()\0"
};

const QMetaObject sul_monitor::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_sul_monitor,
      qt_meta_data_sul_monitor, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &sul_monitor::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *sul_monitor::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *sul_monitor::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_sul_monitor))
        return static_cast<void*>(const_cast< sul_monitor*>(this));
    return QWidget::qt_metacast(_clname);
}

int sul_monitor::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: start_scanner(); break;
        case 1: stop_scanner(); break;
        case 2: step_scanner(); break;
        case 3: set_scanner(); break;
        case 4: dr_change(); break;
        case 5: x0_change(); break;
        case 6: y0_change(); break;
        case 7: angle_change(); break;
        case 8: sector_change(); break;
        case 9: sector_max_change(); break;
        case 10: axis_change(); break;
        case 11: timer_event(); break;
        case 12: iface_change(); break;
        case 13: tool_change((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: tool_change(); break;
        case 15: fill_ram((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: fill_ram(); break;
        case 17: fill_flash((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: fill_flash(); break;
        case 19: detect_abonent_list(); break;
        case 20: prepare_abonent_request(); break;
        case 21: dbg_timer_event(); break;
        case 22: send_abonent_request(); break;
        case 23: zone_change(); break;
        case 24: open_flash(); break;
        case 25: erase_flash(); break;
        case 26: load_flash(); break;
        case 27: check_flash(); break;
        case 28: set_ram(); break;
        case 29: inc_ram_value(); break;
        case 30: dec_ram_value(); break;
        case 31: open_ram(); break;
        case 32: erase_ram(); break;
        case 33: load_ram(); break;
        case 34: save_ram(); break;
        case 35: show_beam_position(); break;
        case 36: show_channells_status(); break;
        case 37: show_calculators_status(); break;
        case 38: show_phase_array(); break;
        case 39: test_widget(); break;
        case 40: processing_status((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 41: display_timer_event(); break;
        case 42: set_antenna_params(); break;
        case 43: set_dbgtimer((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 44: update_abonent_address((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 45: new_cfg_file_create(); break;
        default: ;
        }
        _id -= 46;
    }
    return _id;
}
static const uint qt_meta_data_worker_thread[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      22,   15,   14,   14, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_worker_thread[] = {
    "worker_thread\0\0status\0task_status(int)\0"
};

const QMetaObject worker_thread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_worker_thread,
      qt_meta_data_worker_thread, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &worker_thread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *worker_thread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *worker_thread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_worker_thread))
        return static_cast<void*>(const_cast< worker_thread*>(this));
    return QThread::qt_metacast(_clname);
}

int worker_thread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: task_status((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void worker_thread::task_status(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
