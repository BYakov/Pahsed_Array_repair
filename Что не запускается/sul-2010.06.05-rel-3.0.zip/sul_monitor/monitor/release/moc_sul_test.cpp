/****************************************************************************
** Meta object code from reading C++ file 'sul_test.h'
**
** Created: Sat 5. Jun 09:55:22 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../sul_test.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'sul_test.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_sul_test_widget[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: signature, parameters, type, tag, flags
      17,   16,   16,   16, 0x05,
      33,   16,   16,   16, 0x05,
      51,   16,   16,   16, 0x05,
      78,   70,   16,   16, 0x05,

 // slots: signature, parameters, type, tag, flags
     106,   16,   16,   16, 0x0a,
     122,   16,   16,   16, 0x0a,
     138,   16,   16,   16, 0x0a,
     157,   16,   16,   16, 0x0a,
     175,   16,   16,   16, 0x0a,
     191,   16,   16,   16, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_sul_test_widget[] = {
    "sul_test_widget\0\0view_channels()\0"
    "view_grid_array()\0view_calculators()\0"
    "abonent\0tested_abonent_changed(int)\0"
    "test_exchange()\0test_channels()\0"
    "test_calculators()\0grid_array_show()\0"
    "channels_show()\0abonent_changed(int)\0"
};

const QMetaObject sul_test_widget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_sul_test_widget,
      qt_meta_data_sul_test_widget, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &sul_test_widget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *sul_test_widget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *sul_test_widget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_sul_test_widget))
        return static_cast<void*>(const_cast< sul_test_widget*>(this));
    return QWidget::qt_metacast(_clname);
}

int sul_test_widget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: view_channels(); break;
        case 1: view_grid_array(); break;
        case 2: view_calculators(); break;
        case 3: tested_abonent_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: test_exchange(); break;
        case 5: test_channels(); break;
        case 6: test_calculators(); break;
        case 7: grid_array_show(); break;
        case 8: channels_show(); break;
        case 9: abonent_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void sul_test_widget::view_channels()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void sul_test_widget::view_grid_array()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void sul_test_widget::view_calculators()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void sul_test_widget::tested_abonent_changed(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_END_MOC_NAMESPACE
