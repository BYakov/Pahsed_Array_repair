#include "sul_analizer.h"

///////////////////////////////////////////////////////////////////////
//	    ����� ��� ��������� ��������� �������
///////////////////////////////////////////////////////////////////////

sul_channel_analizer::sul_channel_analizer(QAbstractItemModel *model, QWidget *parent, Qt::WFlags flags)
: QWidget(parent, flags)
{
    setWindowTitle(tr("��������� �������"));
    m = model;
    bar = new QStatusBar(this);
    bar->setSizeGripEnabled(false);
    square_size = 6;
    X = 0;
    N = 0;
    low_level = 30;
    top_level = 50;
    mid_level = 0.5*(low_level+top_level);
}

sul_channel_analizer::~sul_channel_analizer()
{
    m = NULL;
}

void sul_channel_analizer::paintEvent(QPaintEvent *event)
{
    if(!m) return;

    QRectF r = event->rect();

    float w = r.width();
    float h = r.height();
    float xs = w/m->rowCount();

    QPainter p(this);
    QLinearGradient g(0.7*w,h,0,0);
    g.setSpread(QGradient::ReflectSpread);

    QColor c;
    int val = 0;

    p.fillRect(0,0,w,h,QBrush(g));
    p.setPen(Qt::red);

    for(int i=0; i<m->rowCount(); i++) {

        QModelIndex index = m->index(i, 0);

	val = m->data(index,0).toInt();

	if(val >= low_level && val <= top_level) {
	    c = Qt::green;
	} else {
	    c = Qt::red;
	}

	if(val == 0) {
	    c = Qt::blue;
	}

        p.fillRect(xs*i,
		   h - val - (top_level+top_level)*0.5,
                   square_size,
                   square_size,
		   QBrush(c,Qt::SolidPattern));
    }
}

void sul_channel_analizer::mousePressEvent(QMouseEvent *event)
{
    X = event->x();
    N = X*128/geometry().width() + 1;

    QModelIndex index = m->index(N-1, 0);
    QString status;

    int val = m->data(index,0).toInt();

    if(val >= low_level && val <= top_level) {
	status = tr("��������");
    } else {
	if(val < low_level) {
	    status = tr("���������");
	} else {
	    if(val > top_level) {
		status = tr("�����");
	    }
	}
    }

    bar->setGeometry(5,geometry().height()-15,geometry().width()-5,15);
    bar->showMessage(tr("����� ������: ") + QString::number(N) + " - " + status);

    repaint();
}

void sul_channel_analizer::set_model(QAbstractItemModel *model)
{
    m = model;
}
