#ifndef GRID_ARRAY_H
#define GRID_ARRAY_H

#include <QtGui>
#include <QtGui/QWidget>
#include <QTableView>
#include <QStatusBar>
#include <QSettings>
#include <QStandardItemModel>

#include "..\base_class\sul_base.h"

class grid_array : public QWidget
{
    Q_OBJECT
public:
    grid_array(sul_base *Sul,  QAbstractItemModel  *m, QWidget *parent, Qt::WFlags flags);
    virtual ~grid_array();
private:
    sul_base *sul;
    QAbstractItemModel  *model;
    int                 low_level;
    int                 mid_level;
    int                 top_level;
    int                 Radius;
    int                 RowCount;
    int                 ColCount;

protected:
        void paintEvent(QPaintEvent *event);
};

#endif // GRID_ARRAY_H
