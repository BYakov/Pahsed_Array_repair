#include "grid_array.h"

grid_array::grid_array(sul_base *Sul,  QAbstractItemModel  *m, QWidget *parent, Qt::WFlags flags)
: QWidget(parent, flags)
{
    //int D = 10;
    //int W = 30*D;
    //int H = 30*D;
    //setGeometry(0,0,W,H);
    model = m;
    sul = Sul;
}

grid_array::~grid_array()
{
}

void grid_array::paintEvent(QPaintEvent *event)
{
    float w = geometry().width();
    float h = geometry().height();

    QPainter p(this);

    p.drawEllipse(0,0,w,h);

    QBrush b(Qt::green);

    p.setBrush(b);
    for(int i=0; i<10; i++) {
        p.drawEllipse(20*i,h/2-10,20,20);
    }
}
