#ifndef SUL_ANALIZER_H
#define SUL_ANALIZER_H

#include <QtGui>
#include <QtGui/QWidget>
#include <QTableView>
#include <QStatusBar>
#include <QSettings>
#include <QStandardItemModel>

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

class sul_channel_analizer : public QWidget
{
        Q_OBJECT

private:
        QAbstractItemModel  *m;
        QStatusBar          *bar;
        int                 square_size;
	int		    X;
	int		    N;

	int		    low_level;
	int		    mid_level;
	int		    top_level;

public:
        sul_channel_analizer(QAbstractItemModel *m, QWidget *parent = 0, Qt::WFlags flags = 0);
        ~sul_channel_analizer();

protected:
        void paintEvent(QPaintEvent *event);
        void mousePressEvent(QMouseEvent *event);

public:
        void set_model(QAbstractItemModel *m);
//	//void repaint();
};

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

#endif // SUL_ANALIZER_H

