#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>

#include <iostream>
#include <string>
#include <istream>
#include <fstream>
#include <iomanip>

#ifndef _SUL_MDO_H_
#include "sul_mdo.h"
#endif

using namespace std;

//------------------------------------------------------------------------------

sul_mdo::sul_mdo( device *hw, const char *sul_mdo_config, const char *ram_mdo_config ):
sul_base( sul_mdo_config, ram_mdo_config)
{
	cout << "sul_mdo::sul_mdo()" << endl;

	abonents_count = 0;
	abonents_list = NULL;

	packet = new packet485(hw);

	sul_connect_device(hw);

	detect();
}

//------------------------------------------------------------------------------

sul_mdo::~sul_mdo()
{
	cout << "sul_mdo::~sul_mdo()" << endl;

	abonents_count = 0;
	if(abonents_list) delete[] abonents_list;
	if(packet) delete packet;
}

//------------------------------------------------------------------------------

int sul_mdo::detect()
{
	cout << "sul_mdo::detect_abonents()" << endl;
	int i=0;
	unsigned char   addresses[MAX_ABONENT_NUMBER];

	unsigned char   size = 1;
	unsigned char   total = 0;

	memset(addresses,0,sizeof(addresses));

	int   res = 0;
        for(i=1; i<=MAX_ABONENT_NUMBER; i++) {

		res = packet->request(i,target_address,0,&addresses[i-1],size);
		if(res < 0) {
			cout << "detect_abonents(" << i << "): target_address - error" << endl;
			continue;
		} else {
			cout << "detect_abonents(" << i << "): address " << int(addresses[i-1]) << " Ok" << endl;
                        total++;
		}
	}

	if(!total) return 0;

	abonents_list = new abonent[total];
	if(!abonents_list)
		return 0;

	memset(abonents_list,0,sizeof(abonent)*total);

	int index = 0;
	for(i=0; i<MAX_ABONENT_NUMBER; ++i) {
		if(addresses[i]) {
			abonents_list[index].address = addresses[i];
			++index;
		}
	}

	abonents_count = index;
        number_of_abonents = index;

	return index;
}

//------------------------------------------------------------------------------

void sul_mdo::info()
{
	cout << "sul_mdo::info()" << endl;
	int i = 0;
	int res = 0;
	int err = 0;
	for(i=0; i<abonents_count; i++) {

		//������ �� ��������� �� ������ EEPROM �� �����������������
		//������������
		abonents_list[i].config_eeprom_cs = sul_flash_crc(i);

		//������ �� ��������� �� ������ EEPROM ���������� � ����������
		res = packet->request(abonents_list[i].address,
			target_eeprom_crc,
			0, &abonents_list[i].device_eeprom_cs, 2);
		if(res < 0) {
			cout << "sul_mdo::info(): Abonent " << i << ": target_eeprom_crc - error" << endl;
			--err;
		}

		//������ �� ��������� �� ������ RAM ���������� � ����������
		res = packet->request(abonents_list[i].address,
			target_ram_crc,
			0, &abonents_list[i].device_ram_cs, 2);
		if(res < 0) {
			cout << "sul_mdo::info(): Abonent " << i << ": target_eeprom_crc - error" << endl;
			--err;
		}
	}
}

//------------------------------------------------------------------------------

int sul_mdo::write_eeprom_block(int zone, int block)
{
        //cout << "sul_mdo::write_eeprom_block()" << endl;

	unsigned char *data = (unsigned char*)flash_data_block(zone,block);
	if(!data) {
                cout << "write_eeprom_block(): invalid block address" << endl;
		return -1;
	}

        //Sleep(40);

        int res = packet->request(abonent_address(block),host_eeprom_data,zone,data,flash_block_size());
	if(res < 0) {
		cout << "write_eeprom_block(): target_eeprom_data - error." << endl;
		return -1;
	}

	return 0;
}

//------------------------------------------------------------------------------
/*
int sul_mdo::read_eeprom_block(int zone, int block)
{
	cout << "sul_mdo::read_eeprom_block()" << endl;

	unsigned char *dev_data = (unsigned char *)calloc(flash_block_size(), 1);
	if(!dev_data) {
		cout << "read_eeprom_block(): invalid block address" << endl;
		return -1;
	}

        int res = packet->request(abonent_address(block),target_eeprom_data,zone,dev_data,flash_block_size());
	if(res < 0) {
		cout << "read_eeprom_block(): target_eeprom_data - error." << endl;
                free(dev_data);
		return -1;
	}

        free(dev_data);
	return 0;
}
*/
//------------------------------------------------------------------------------

int sul_mdo::write_ram_block(int zone, int block)
{
        cout << "sul_mdo::write_ram_block()" << endl;

        unsigned char *data = (unsigned char*)ram_data_block(zone,block);
        if(!data) {
                cout << "write_ram_block(): invalid block address" << endl;
                return -1;
        }

        int res = packet->request(abonent_address(block),host_ram_data,zone,data,ram_block_size());
        if(res < 0) {
                cout << "write_ram_block(): host_ram_data - error." << endl;
                return -1;
        }

        return 0;
}

//------------------------------------------------------------------------------
/*
int sul_mdo::read_ram_block(int zone, int block)
{
        cout << "sul_mdo::read_ram_block()" << endl;

        unsigned char *dev_data = (unsigned char *)calloc(ram_block_size(), 1);
        if(!dev_data) {
                cout << "read_ram_block(): invalid block address" << endl;
                return -1;
        }

        int res = packet->request(abonent_address(block),target_ram_data,zone,dev_data,ram_block_size());
        if(res < 0) {
                cout << "read_ram_block(): target_ram_data - error." << endl;
                free(dev_data);
                return -1;
        }

        free(dev_data);

        return 0;
}
*/
//------------------------------------------------------------------------------

bool sul_mdo::check_address(int index)
{
    if(index >= abonents_count || !abonents_list ) {
            return false;
    }
    return true;
}

//------------------------------------------------------------------------------

unsigned char sul_mdo::abonent_address(int index)
{
        //cout << "sul_mdo::abonent_address(" << index << ")" << endl;
	if(index > abonents_count || !abonents_list ) {
                //cout << "abonent_address(): index is greater than total abonents number" << endl;
                return 0xff;
	}
	return abonents_list[index].address;
}

//------------------------------------------------------------------------------

int sul_mdo::test_exchange( int devn )
{
	int res = -1;
	int i=0;
	const int N = 128;
	unsigned char tx[N];
	unsigned char rx[N];

        if(!check_address(devn))
            return -1;

	memset(rx,0,N);
	memset(tx,0,N);

	res = packet->request(devn,host_to_target,0,tx,N);
	if(res < 0) {
		cout << "test_exchange(" << devn << "): Transmitt error." << endl;
		return -1;
	}

	res = packet->request(devn,target_to_host,0,rx,N);
	if(res < 0) {
		cout << "test_exchange(" <<  devn << "): Receive error." << endl;
		return -1;
	}

	res = 0;
	for(i=0; i<N; i++) {
		if(rx[i] != tx[i]) res++;
	}

	cout << "test_exchange(" <<  devn << "): total error " << res << endl;

	return res;
}

//------------------------------------------------------------------------------

int sul_mdo::test_calculators( int devn )
{
	int res = -1;
	int i=0;
	const int N = 128;
	unsigned char rx[N];

        if(!check_address(devn))
            return -1;

	memset(rx,0,N);

	res = packet->request(devn,target_ctrl_calc,0,NULL,0);
	if(res < 0) {
		cout << "test_calculators(" <<  devn << "): Control calculators error." << endl;
		return -1;
	}

	Sleep(500);

	res = packet->request(devn,target_calc_return,0,rx,N);
	if(res < 0) {
		cout << "test_calculators(" <<  devn << "): Receive error." << endl;
		return -1;
	}

	res = 0;
	for(i=0; i<N; i++) {
		if(rx[i] != 0) res++;
	}

	cout << "test_calculators(" <<  devn << "): total error " << res << endl;

	return res;
}

//------------------------------------------------------------------------------

int sul_mdo::test_channels( int devn )
{
	int res = -1;
	int i=0;
	const int N = 128;
	unsigned char rx[N];

        if(!check_address(devn))
            return -1;

	memset(rx,0,N);

	res = packet->request(devn,target_ctrl_channel,0,NULL,0);
	if(res < 0) {
		cout << "test_channels(" <<  devn << "): Control calculators error." << endl;
		return -1;
	}

	Sleep(500);

	res = packet->request(devn,target_calc_return,0,rx,N);
	if(res < 0) {
		cout << "test_channels(" <<  devn << "): Receive error." << endl;
		return -1;
	}

	res = 0;
	for(i=0; i<N; i++) {
		if(rx[i] != 0) res++;
	}

	cout << "test_channels(" <<  devn << "): total error " << res << endl;        

	return res;
}

//------------------------------------------------------------------------------
//              ���������� ���������� �������� ������            
//------------------------------------------------------------------------------

int sul_mdo::sul_init(int devn)
{
	cout << "sul_mdo::sul_init()" << endl;

	int res = 0;
	int err = 0;

        if(devn == 0) {

            for(int i=0; i<abonents_count; ++i) {

                    if(!check_address(i))
                        continue;

                    res = packet->request(abonent_address(i),target_eeprom_to_plm, 0, NULL, 0);
                    if(res < 0) {
                            cout << "sul_flash_crc(): Abonent " << int(abonent_address(i)) << ": target_reset - error" << endl;
                            --err;
                            continue;
                    }
            }

            return err;

        }

        --devn;

        if(!check_address(devn))
            return -1;

        res = packet->request(abonent_address(devn),target_eeprom_to_plm, 0, NULL, 0);
        if(res < 0) {
                    cout << "sul_flash_crc(): Abonent " << int(abonent_address(devn)) << ": target_reset - error" << endl;
                    --err;
        }

	return err;
}

//------------------------------------------------------------------------------

int sul_mdo::sul_reset(int devn)
{
	cout << "sul_mdo::sul_reset()" << endl;

	int res = 0;
        int err = 0;

        if(devn == 0) {

            for(int i=0; i<abonents_count; ++i) {

                if(!check_address(i))
                    continue;

                res = packet->request(abonent_address(i), target_reset, 0, NULL, 0);
		if(res < 0) {
			cout << "sul_flash_crc(): Abonent " << i << ": target_reset - error" << endl;
			--err;
			continue;
		}
            }

            return err;
        }

        --devn;

        if(!check_address(devn))
                return -1;

        res = packet->request(abonent_address(devn),target_reset, 0, NULL, 0);
        if(res < 0) {
                    cout << "sul_flash_crc(): Abonent " << int(abonent_address(devn)) << ": target_reset - error" << endl;
                    --err;
        }

	return err;
}

//------------------------------------------------------------------------------

int sul_mdo::sul_channels(int devn)
{
    if(devn) return number_of_channels;

    return number_of_channels*number_of_abonents;
}

//------------------------------------------------------------------------------

int sul_mdo::sul_test(int devn)
{
	//�������� ������
	//�������� ������������
	//�������� �������
	return -1;
}

//------------------------------------------------------------------------------

int sul_mdo::sul_test(int devn, unsigned char *buffer, int size)
{
    int res = 0;

    devn--;

    if(!check_address(devn) || !buffer || !size)
	return -1;

    res = packet->request(abonent_address(devn), target_ctrl_channel, 0, NULL, 0);
    if(res < 0) {
	cout << "sul_test(): Abonent " << int(abonent_address(devn)) << ": target_ctrl_channel - error" << endl;
	return -1;
    }

    Sleep(500);

    res = packet->request(abonent_address(devn), target_channel_return, 0, buffer, size);
    if(res < 0) {
	cout << "sul_test(): Abonent " << int(abonent_address(devn)) << ": target_channel_return - error" << endl;
	return -1;
    }

    return 0;
}

//------------------------------------------------------------------------------

int sul_mdo::sul_beam_position(u16 x, u16 y, u8 zone, ray_type type)
{
	return packet->request(x,y,zone);
}

//------------------------------------------------------------------------------

struct sul_state sul_mdo::sul_state(int devn)
{
	struct sul_state st = {0};

	if(!devn) {

		for(int i=0; i<abonents_count; i++) {
			g_state.exch_err += test_exchange(abonent_address(i));
			g_state.calc_err += test_calculators(abonent_address(i));
			g_state.chan_err += test_channels(abonent_address(i));
		}

		return g_state;
	}

	cout << "sul_mdo::sul_state(" << devn <<")" << endl;

	//�������� ������
	st.exch_err = test_exchange(abonent_address(devn));

	//�������� ������������
	st.calc_err = test_calculators(abonent_address(devn));

	//�������� �������
	st.chan_err += test_channels(abonent_address(devn));

	return st;
}

//------------------------------------------------------------------------------
//                              ������ � FLASH
//------------------------------------------------------------------------------

int sul_mdo::sul_flash_erase(int devn)
{
	struct host_dbg_header hdr = {0};
	cout << "sul_mdo::sul_erase_flash()" << endl;

	int res = 0;
	int err = 0;

	dev->reset();

	//������� FLASH � ���� ���������
        if(devn == 0) {

		for(int i=0; i<abonents_count; ++i) {

                        if(!check_address(i))
                            continue;

			cout << "Erasing abonents " << int(abonent_address(i)) << " EEPROM ..." << endl;
			/*
			res = packet->request(abonent_address(i), target_eeprom_clear, flash::info.zones, NULL, 0);
			if(res < 0) {
				cout << "sul_flash_erase(): Abonent " << int(abonent_address(i)) << ": target_eeprom_clear - error" << endl;
				--err;
				continue;
                        } else {
                            cout << " - COMPLETE" << endl;
                        }
			*/
			hdr = packet->create_dbg_header(abonent_address(i),target_eeprom_clear,flash::info.zones, NULL, 0);
			if( dev->write_raw(&hdr,sizeof(struct host_dbg_header)) < 0 ) {
			    cout << "sul_flash_erase(): Abonent " << int(abonent_address(i)) << ": target_eeprom_clear - error" << endl;
			    --err;
			}
			Sleep(200);
		}

		Sleep(15000);

		for(int i=0; i<abonents_count; ++i) {

		    struct target_dbg_header thdr = {0};

		    if( dev->read_raw(&thdr,sizeof(struct target_dbg_header)) != sizeof(struct target_dbg_header) ) {
			cout << "sul_flash_erase(): Abonent " << int(abonent_address(i)) << ": header error" << endl;
			--err;
			continue;
		    } else {
			if( thdr.code != target_eeprom_clear ||
			    thdr.sign != target_signature ) {
			    cout << "sul_flash_erase(): Abonent " << int(abonent_address(i)) << ": address error" << endl;
			} else {
			    cout << "Abonent " << int(thdr.addr) << " - COMPLETE" << endl;
			}
		    }
		}

		return err;
	}

        --devn;

        if(!check_address(devn))
            return -1;

        res = packet->request(abonent_address(devn), target_eeprom_clear, flash::info.zones, NULL, 0);
	if(res < 0) {
                cout << "sul_flash_erase(): Abonent " << int(abonent_address(devn)) << ": target_eeprom_clear - error" << endl;
		--err;
	}

	return err;
}

//------------------------------------------------------------------------------

int sul_mdo::sul_flash_load(const char *fname, int devn)
{
	cout << "sul_mdo::sul_load_flash( " <<
		(fname ? fname : flash_config_file()) << " )" << endl;

	if(fname) {
                if( sul_flash_reconfig(fname) < 0) {
                        flash::log.msg("������ �������������� ������������ FLASH!");
			return -1;
		}
	}

        int err = 0;

        if(devn == 0) {

            //��������� ������ �� ����� �� FLASH ���������
            for(int current_zone=0; current_zone < flash::info.zones; ++current_zone) {

                    for(int current_block=0; current_block < flash::info.blocks_in_zone; ++current_block) {

                            if(!check_address(current_block))
                                continue;

                            cout << "Loading ... [" << current_zone << "]:[" << current_block << "]";

                            if( write_eeprom_block( current_zone, current_block ) < 0 ) {
                                    cout << " - ERROR" << endl;
                                    --err;
                                    break;
                            }

                            cout << " - COMPLETE" << endl;

                            Sleep(400);
                    }
            }

            return err;

        }

        --devn;

        if(!check_address(devn))
            return -1;

         cout << "sul_mdo::sul_load_flash( " << int(abonent_address(devn)) << " )" << endl;

         //��������� ������ �� ����������������� ������������ �� FLASH ��������
         for(int current_zone=0; current_zone < flash::info.zones; ++current_zone) {

            cout << "loading... [" << current_zone << "]:[" << devn << "]";

            if( write_eeprom_block( current_zone, devn ) < 0 ) {
                cout << " - ERROR" << endl;
                --err;
                break;
            }

            cout << " - COMPLETE" << endl;
        }

        return err;
}

//------------------------------------------------------------------------------

u16 sul_mdo::sul_flash_crc(int devn)
{
	cout << "sul_mdo::sul_flash_crc()" << endl;

	int res = 0;
	int err = 0;
	u16 abonent_crc[MAX_ABONENT_NUMBER] = {0};
	u16 crc = 0;

        if(devn == 0) {

            for(int i=0; i<abonents_count; ++i) {

                if(!check_address(i))
                    continue;

                res = packet->request(abonent_address(i), target_eeprom_crc, flash::info.zones, &abonent_crc[i], sizeof(u16));
                    if(res < 0) {
                            cout << "sul_flash_crc(): Abonent " << int(abonent_address(i)) << ": target_eeprom_crc - error" << endl;
                            --err;
                            continue;
                    } else {
                            cout << "sul_flash_crc(): Abonent " << int(abonent_address(i)) << ": crc " << hex << int(abonent_crc[i]) << endl;
                            cout << dec << endl;

                            crc += abonent_crc[i];
                    }
            }

            return err;

        }

        --devn;

        if(!check_address(devn))
            return -1;

        res = packet->request(abonent_address(devn), target_eeprom_crc, flash::info.zones, &abonent_crc[devn], sizeof(u16));
        if(res < 0) {
            cout << "sul_flash_crc(): Abonent " << int(abonent_address(devn)) << ": target_eeprom_crc - error" << endl;
            --err;
        } else {
            cout << "sul_flash_crc(): Abonent " << int(abonent_address(devn)) << ": crc " << hex << int(abonent_crc[devn]) << endl;
            cout << dec << endl;
        }
        crc = abonent_crc[devn];

        return crc;
}

//------------------------------------------------------------------------------

int sul_mdo::sul_flash_save(const char *file)
{
        if(file)
            cout << "sul_flash_save(" << file << ")" << endl;

        return flash::space_save_memory(file);
}

//------------------------------------------------------------------------------
//      ������ � RAM
//------------------------------------------------------------------------------

int sul_mdo::sul_ram_load(const char *fname, int devn)
{
    cout << "sul_mdo::sul_ram_load( " <<
            (fname ? fname : ram_config_file()) << " )" << endl;

    if(fname) {
            if( sul_ram_reconfig(fname) < 0) {
                    ram::log.msg("������ �������������� ������������ RAM!");
                    return -1;
            }
    }

    int err = 0;

    if(devn == 0) {

        //��������� ������ ����������������� ������������ � RAM ���������
        for(int current_zone=0; current_zone < ram::info.zones; ++current_zone) {

                for(int current_block=0; current_block < ram::info.blocks_in_zone; ++current_block) {

                        if(!check_address(current_block))
                            continue;

                        cout << "loading... [" << current_zone << "]:[" << current_block << "]";

                        if( write_ram_block( current_zone, current_block ) < 0 ) {
                                cout << " - ERROR" << endl;
                                --err;
                                break;
                        }

                        cout << " - COMPLETE" << endl;
                }
        }

        return err;

    }

    --devn;

     if(!check_address(devn))
        return -1;

     cout << "sul_mdo::sul_ram_load( " << int(abonent_address(devn)) << " )" << endl;

     //��������� ������ �� ����������������� ������������ � RAM ��������
     for(int current_zone=0; current_zone < ram::info.zones; ++current_zone) {

        cout << "loading... [" << current_zone << "]:[" << devn << "]";

        if( write_ram_block( current_zone, devn ) < 0 ) {
            cout << " - ERROR" << endl;
            --err;
            break;
        }

        cout << " - COMPLETE" << endl;
    }

    return err;
}

//------------------------------------------------------------------------------

int sul_mdo::sul_ram_save(const char *file)
{
    if(file)
        cout << "sul_ram_save( " << file << " )" << endl;

    return ram::space_save_memory(file);
}

//------------------------------------------------------------------------------

int sul_mdo::sul_ram_erase(int devn)
{
    cout << "sul_mdo::sul_ram_erase()" << endl;

    int res = 0;
    int err = 0;

    if(devn == 0) {

        for(int i=0; i<abonents_count; ++i) {

                if(!check_address(i))
                    continue;

                res = packet->request(abonent_address(i), target_ram_clear, 0, NULL, 0);
                if(res < 0) {
                        cout << "sul_ram_erase(): Abonent " << int(abonent_address(i)) << ": target_ram_clear - error" << endl;
                        --err;
                        continue;
                } else {
                        cout << "sul_ram_erase(): Abonent " << int(abonent_address(i)) << " ram erased" << endl;
                }
        }

        return err;
    }

    --devn;

    if(!check_address(devn))
        return -1;

    res = packet->request(abonent_address(devn), target_ram_clear, 0, NULL, 0);
    if(res < 0) {
            cout << "sul_ram_erase(): Abonent " << int(abonent_address(devn)) << ": target_ram_clear - error" << endl;
            --err;
    } else {
            cout << "sul_ram_erase(): Abonent " << int(abonent_address(devn)) << " ram erased" << endl;
    }

    return err;
}

//------------------------------------------------------------------------------

u16 sul_mdo::sul_ram_crc(int devn)
{
    cout << "sul_mdo::sul_ram_crc()" << endl;

    int res = 0;
    int err = 0;
    u16 abonent_crc[MAX_ABONENT_NUMBER] = {0};
    u16 crc = 0;

    if(devn == 0) {

        for(int i=0; i<abonents_count; ++i) {

                res = packet->request(abonent_address(i), target_ram_crc, 0, &abonent_crc[i], sizeof(u16));
                if(res < 0) {
                        cout << "sul_ram_crc(): Abonent " << int(abonent_address(i)) << ": target_ram_crc - error" << endl;
                        --err;
                        continue;
                } else {
                        cout << "sul_ram_crc(): Abonent " << int(abonent_address(i)) << ": crc " << hex << int(abonent_crc[i]) << endl;
                        cout << dec << endl;
                }
                crc += abonent_crc[i];
        }

        if(err < 0)
            return 0xffff;
        else
            return crc;
    }

    --devn;

    if(!check_address(devn))
        return -1;

    res = packet->request(abonent_address(devn), target_ram_crc, 0, &abonent_crc[devn], sizeof(u16));
    if(res < 0) {
        cout << "sul_ram_crc(): Abonent " << int(abonent_address(devn)) << ": target_ram_crc - error" << endl;
        --err;
    } else {
        cout << "sul_ram_crc(): Abonent " << int(abonent_address(devn)) << ": crc " << hex << int(abonent_crc[devn]) << endl;
        cout << dec << endl;
    }
    crc = abonent_crc[devn];

    if(err < 0)
        return 0xffff;
    else
        return crc;
}

//------------------------------------------------------------------------------

