#include "sul_monitor.h"
#include <QtGui/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	sul_monitor w;
	w.show();
	return a.exec();
}
