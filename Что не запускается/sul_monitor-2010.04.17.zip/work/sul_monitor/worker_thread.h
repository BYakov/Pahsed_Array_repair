#ifndef WORKER_THREAD_H
#define WORKER_THREAD_H

#include <QtGui>
#include <QThread>

#include "..\sul_src\sul_mdo.h"
#include "..\sul_src\sul_avr.h"
#include "..\sul_src\serial.h"
#include "..\sul_src\scanner.h"
#include "..\sul_src\packet485.h"
#include "..\sul_src\angle_correct.h"

//-----------------------------------------------------------------------------

class worker_thread : public QThread {

private:
    worker_thread();

public:
    worker_thread(sul_base *Sul);
    virtual ~worker_thread();

private:
    sul_base *sul;
    bool exit_ok;
    bool paused;
    int  task_code;
    void run();

public:
    void start_task(Priority priority, int task);
    void stop_task();
    void pause_task(bool state);
};

//-----------------------------------------------------------------------------

#endif // WORKER_THREAD_H

