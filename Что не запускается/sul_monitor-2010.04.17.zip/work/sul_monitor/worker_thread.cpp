
#include <iostream>
#include <string>
#include <istream>
#include <fstream>
#include <iomanip>

using namespace std;

#include "worker_thread.h"

//---------------------------------------------------------------------------------------

worker_thread::worker_thread() : QThread()
{
    exit_ok = true;
    sul = NULL;
}

//---------------------------------------------------------------------------------------

worker_thread::worker_thread(sul_base *Sul) : QThread()
{
    exit_ok = false;
    sul = Sul;
}

//---------------------------------------------------------------------------------------

worker_thread::~worker_thread()
{
    if(isRunning()) {
	stop_task();
	wait();
    }
}

//---------------------------------------------------------------------------------------

void worker_thread::run()
{
    cout << "scanner_thread::run()" << endl;

    setTerminationEnabled(false);

    while(!exit_ok) {

	if(paused)
	    continue;

	cout << "still working..." << endl;
    }

    cout << "stopped" << endl;

    terminate();
}

//-----------------------------------------------------------------------------

void worker_thread::start_task( Priority priority, int task )
{
    cout << "worker_thread::start_thread()" << endl;

    if(!sul) return;

    exit_ok = false;
    paused = false;
    task_code = task;

    QThread::start(priority);
}

//-----------------------------------------------------------------------------

void worker_thread::stop_task()
{
    cout << "worker_thread::stop_thread()" << endl;
    setTerminationEnabled(true);
    exit_ok = true;
}

//-----------------------------------------------------------------------------

void worker_thread::pause_task(bool state)
{
    cout << "pause = " << state << endl;
    paused = state;
}

//-----------------------------------------------------------------------------


