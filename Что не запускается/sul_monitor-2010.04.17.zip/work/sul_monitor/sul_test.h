#ifndef SUL_TEST_H
#define SUL_TEST_H

#include <QtGui>
#include <QtGui/QWidget>
#include <QTableView>
#include <QStatusBar>
#include <QSettings>
#include <QStandardItemModel>

#include "..\base_class\sul_base.h"

#include "sul_analizer.h"

class sul_test_widget : public QWidget
{
	Q_OBJECT

private:
	QAbstractItemModel *model;
	sul_base *sul;

	QLabel *label;
	QSpinBox *box;
	QPushButton *btnCtrl;
	QStatusBar  *bar;


public:
	sul_test_widget(sul_base *s, QAbstractItemModel *m, QWidget *parent = 0, Qt::WFlags flags = 0);
	virtual ~sul_test_widget();

signals:
	void view_channels();

public slots:
	void test_channels();
};

#endif // SUL_TEST_H
