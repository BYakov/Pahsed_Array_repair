
#include "sul_test.h"

#include <iostream>
#include <string>
#include <istream>
#include <fstream>
#include <iomanip>

using namespace std;

sul_test_widget::sul_test_widget(sul_base *s, QAbstractItemModel *m, QWidget *parent, Qt::WFlags flags):
	QWidget(parent,flags)
{
    setWindowTitle(tr("��������"));

    QVBoxLayout *layout = new QVBoxLayout(this);
    label = new QLabel(tr("�������"));
    box = new QSpinBox();
    btnCtrl = new QPushButton(tr("�����"));
    bar = new QStatusBar();

    box->setValue(1);
    box->setMaximum(5);
    box->setMinimum(1);

    layout->addWidget(label);
    layout->addWidget(box);
    layout->addWidget(btnCtrl);
    layout->addWidget(bar);

    connect(btnCtrl,SIGNAL(clicked()),this,SLOT(test_channels()));

    model = m;
    sul = s;
}

//-----------------------------------------------------------------------------

sul_test_widget::~sul_test_widget()
{
}

//-----------------------------------------------------------------------------

void sul_test_widget::test_channels()
{
    if(!sul || !model)
	return;

    int abonent = box->value();
    int size = sul->sul_channels(abonent);

    unsigned char *buffer = (unsigned char *)malloc(size);
    if(!buffer)
	return;

    memset(buffer,0,size);

    cout << "sul_test_widget::test_channels() - abonent " << abonent << endl;

    if(sul->sul_test(abonent, buffer, size) < 0) {
	    cout << "sul_test_widget::test_channels() - Error" << endl;
	    free(buffer);
	    bar->showMessage(tr("������ ��������"));
	    return;
    }

    // ���������� ������� ����������� ������
    for (int nCol = 0; nCol < model->columnCount(); ++nCol) {
	for (int nRow = 0; nRow < size; ++nRow) {
	    QModelIndex index = model->index(nRow, nCol);
	    model->setData( index, int(buffer[nRow]) );
	    //cout << nRow << ":" << int(buffer[nRow]) << endl;
	}
    }

    free(buffer);

    emit view_channels();

    bar->showMessage(tr("�������� ��������"));
}

//-----------------------------------------------------------------------------
