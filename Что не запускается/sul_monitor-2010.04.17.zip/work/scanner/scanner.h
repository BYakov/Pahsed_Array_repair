#ifndef SCANNER_H
#define SCANNER_H

#include <QtGui>
#include <QtGui/QWidget>
#include <QTableView>
#include <QThread>
#include <QStatusBar>
#include <QSettings>
#include <QStandardItemModel>

#include <iostream>
#include <string>
#include <istream>
#include <fstream>
#include <iomanip>

#include "..\base_class\device.h"
#include "..\base_class\sul_config.h"
#include "..\sul_src\serial.h"
#include "..\sul_src\sul_mdo_cmd.h"

//-----------------------------------------------------------------------------

using namespace std;

//-----------------------------------------------------------------------------

namespace Ui {
    class scanner;
}

//-----------------------------------------------------------------------------

class scanner_thread;
class raw_parser;

//-----------------------------------------------------------------------------

class scanner : public QWidget {
    Q_OBJECT
public:
    scanner(QWidget *parent = 0);
    virtual ~scanner();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::scanner         *ui;
    QStatusBar          *bar;
    QSettings           *settings;
    device              *hw;
    scanner_thread      *scan;
    raw_parser          *parser;

    int open();
    int close();

public slots:

    void start();
    void stop();
    void pause();
    void parse();

    void raw_update(int N);
};

//-----------------------------------------------------------------------------

class scanner_thread : public QThread {

    Q_OBJECT
public:

    explicit scanner_thread( device *hw );
    virtual ~scanner_thread();
    void     stop_thread();
    void     start_thread( Priority priority = InheritPriority );
    void     pause_thread(bool state);

private:

    bool             init_ok;
    bool             paused;
    bool             exit_ok;
    device          *dev;

    virtual void run();

    int print_target_header(fstream &ofs);
    int print_host_header(fstream &ofs);
    int print_main_header(fstream &ofs);
    int print_data(fstream &ofs, int N);
    int print_error(fstream &ofs);

signals:
    void    raw_bytes_read(int N);
};

//-----------------------------------------------------------------------------

class raw_parser : public space {
public:

    explicit raw_parser(const char *file);
    virtual ~raw_parser();

    int      parse_raw_file(const char *fmtfile, const char *rawfile = NULL);

private:
    QString cmd_to_string(int cmd);
    QString type_to_string(int type);
    int     print_host_header(fstream &ofs, struct host_dbg_header *hdr);
    int     print_target_header(fstream &ofs, struct target_dbg_header *hdr);
    int     print_main_header(fstream &ofs, struct main_packet *mhdr);
    int     print_data(fstream &ofs, struct host_dbg_header *hdr, unsigned char *data, int N);
    int     print_error(fstream &ofs, int error_type = 0 );
};

//-----------------------------------------------------------------------------

#endif // SCANNER_H
